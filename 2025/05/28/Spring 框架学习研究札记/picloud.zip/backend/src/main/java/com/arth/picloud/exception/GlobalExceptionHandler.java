package com.arth.picloud.exception;

import com.arth.picloud.common.BaseResponse;
import com.arth.picloud.common.ResultUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(value = BackendException.class)
    public BaseResponse<?> backendExceptionHandler(BackendException e) {
        log.error("BackendException", e);
        return ResultUtils.error(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(value = RuntimeException.class)
    public BaseResponse<?> backendExceptionHandler(RuntimeException e) {
        log.error("RuntimeException", e);
        return ResultUtils.error(ErrorCode.INTERNAL_SERVER_ERROR, "Internal Server Error");
    }
}
