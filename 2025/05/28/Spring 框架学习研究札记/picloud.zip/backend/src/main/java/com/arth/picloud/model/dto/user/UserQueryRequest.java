package com.arth.picloud.model.dto.user;

import com.arth.picloud.common.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 用户查询请求数据传输对象（DTO）
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UserQueryRequest extends PageRequest implements Serializable {

    private static final long serialVersionUID = -5798146184557090191L;

    private Long id;

    private String userName;

    private String userAccount;

    private String userProfile;

    private String userRole;
}
