package com.arth.picloud.model.dto.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户登录请求数据传输对象（DTO）
 */
@Data
public class UserLoginRequest implements Serializable {

    private static final long serialVersionUID = 763586634272398409L;

    private String userAccount;

    private String userPassword;
}