package com.arth.picloud.model.dto.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户注册请求数据传输对象（DTO）
 */
@Data
public class UserRegisterRequest implements Serializable {

    private static final long serialVersionUID = 3635008898397293893L;

    private String userAccount;

    private String userPassword;

    private String recreatePassword;
}