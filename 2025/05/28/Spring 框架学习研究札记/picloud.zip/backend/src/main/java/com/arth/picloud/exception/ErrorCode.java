package com.arth.picloud.exception;

import lombok.Getter;

@Getter
public enum ErrorCode {

    SUCCESS(0, "OK"),
    INTERNAL_SERVER_ERROR(50001, "Internal Server Error"),
    INVALID_PARAM(40001, "Invalid Parameter"),
    NOT_LOGIN(40101, "Unauthorized"),
    PERMISSION_DENIED(40301, "Forbidden"),
    RESOURCE_NOT_FOUND(40401, "Not Found");

    private final int code;

    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
