package com.arth.picloud;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@MapperScan("com.arth.picloud.mapper")
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class PicloudApplication {

    public static void main(String[] args) {
        SpringApplication.run(PicloudApplication.class, args);
    }
}