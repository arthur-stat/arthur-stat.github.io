package com.arth.picloud.aop;

import com.arth.picloud.annotation.AuthCheck;
import com.arth.picloud.exception.ErrorCode;
import com.arth.picloud.exception.ThrowUtils;
import com.arth.picloud.model.entity.User;
import com.arth.picloud.model.enums.UserRoleEnum;
import com.arth.picloud.service.UserService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Aspect
@Component
public class AuthInterceptor {

    @Resource
    private UserService userService;

    @Around("@annotation(authCheck)")
    public Object doIntercept(final ProceedingJoinPoint joinPoint, AuthCheck authCheck) throws Throwable {
        // 获取所要求的用户身份
        String requiredUserRole = authCheck.requiredUserRole();
        UserRoleEnum requiredUserRoleEnum = UserRoleEnum.getByValue(requiredUserRole);

        // 若无权限要求
        if (requiredUserRoleEnum == null) return joinPoint.proceed();

        // 获取当前登录用户的身份
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = requestAttributes.getRequest();
        User currentUser = userService.getLoginUser(request);
        UserRoleEnum currentUserRoleEnum = UserRoleEnum.getByValue(currentUser.getUserRole());

        // 鉴权
        // 若用户未登录
        ThrowUtils.throwIf(
                currentUserRoleEnum == null,
                ErrorCode.NOT_LOGIN, "未登录");

        // 若登录的用户无足够的权限
        ThrowUtils.throwIf(
                requiredUserRoleEnum.equals(UserRoleEnum.ADMIN) && !currentUserRoleEnum.equals(UserRoleEnum.ADMIN),
                ErrorCode.PERMISSION_DENIED, "当前用户权限不足");

        // 通过权限验证
        return joinPoint.proceed();
    }
}
