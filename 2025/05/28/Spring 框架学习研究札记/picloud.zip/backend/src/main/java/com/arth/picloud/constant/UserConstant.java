package com.arth.picloud.constant;

public interface UserConstant {

    String USER_LOGIN_STATE = "user_login";

    String DEFAULT_ROLE = "user";

    String ADMIN_ROLE = "admin";
}
