package com.arth.picloud.exception;

import lombok.Getter;

@Getter
public class BackendException extends RuntimeException {

    private final int code;

    public BackendException(int code, String message) {
        super(message);
        this.code = code;
    }

    public BackendException(ErrorCode errorCode, String message) {
        this(errorCode.getCode(), message);
    }

    public BackendException(ErrorCode errorCode) {
        this(errorCode.getCode(), errorCode.getMessage());
    }
}
