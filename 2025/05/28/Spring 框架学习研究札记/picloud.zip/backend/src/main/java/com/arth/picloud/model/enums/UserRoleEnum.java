package com.arth.picloud.model.enums;

import cn.hutool.core.util.ObjUtil;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@Getter
public enum UserRoleEnum {

    USER("用户", "user"),
    ADMIN("管理员", "admin");

    private static final Map<String, UserRoleEnum> VALUE_MAP = new HashMap<>();

    private final String description;

    private final String value;

    static {
        for (UserRoleEnum e : values()) {
            VALUE_MAP.put(e.value, e);
        }
    }

    UserRoleEnum(String description, String value) {
        this.description = description;
        this.value = value;
    }

    /**
     * 根据 value 获取枚举类
     *
     * @param value 枚举类的 value 字段
     * @return 返回枚举类
     */
    public static UserRoleEnum getByValue(String value) {
        return VALUE_MAP.get(value);
    }
}
