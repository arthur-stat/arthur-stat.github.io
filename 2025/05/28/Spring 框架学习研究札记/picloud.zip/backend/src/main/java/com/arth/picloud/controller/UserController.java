package com.arth.picloud.controller;

import com.arth.picloud.annotation.AuthCheck;
import com.arth.picloud.common.BaseResponse;
import com.arth.picloud.common.DeleteRequest;
import com.arth.picloud.common.ResultUtils;
import com.arth.picloud.constant.UserConstant;
import com.arth.picloud.exception.ErrorCode;
import com.arth.picloud.exception.ThrowUtils;
import com.arth.picloud.model.dto.user.*;
import com.arth.picloud.model.entity.User;
import com.arth.picloud.model.vo.LoginUserVO;
import com.arth.picloud.model.vo.UserVO;
import com.arth.picloud.service.UserService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    /**
     * 用户注册
     */
    @PostMapping("/register")
    public BaseResponse<Long> userRegister(@RequestBody UserRegisterRequest userRegisterRequest) {
        ThrowUtils.throwIf(userRegisterRequest == null, ErrorCode.INVALID_PARAM);
        String userAccount = userRegisterRequest.getUserAccount();
        String userPassword = userRegisterRequest.getUserPassword();
        String recreatePassword = userRegisterRequest.getRecreatePassword();
        long userId = userService.userRegister(userAccount, userPassword, recreatePassword);
        return ResultUtils.success(userId);
    }

    /**
     * 用户登录
     */
    @PostMapping("/login")
    public BaseResponse<LoginUserVO> userLogin(@RequestBody UserLoginRequest userLoginRequest, HttpServletRequest request) {
        ThrowUtils.throwIf(userLoginRequest == null, ErrorCode.INVALID_PARAM);
        String userAccount = userLoginRequest.getUserAccount();
        String userPassword = userLoginRequest.getUserPassword();
        LoginUserVO loginUserVO = userService.userLogin(userAccount, userPassword, request);
        return ResultUtils.success(loginUserVO);
    }

    /**
     * 获取当前登录用户
     */
    @GetMapping("/get/login")
    public BaseResponse<LoginUserVO> getLoginUser(HttpServletRequest request) {
        User user = userService.getLoginUser(request);
        LoginUserVO userVO = userService.getLoginUserVO(user);
        return ResultUtils.success(userVO);
    }

    /**
     * 用户登录
     */
    @PostMapping("/logout")
    public void userLogout(HttpServletRequest request) {
        userService.userLogout(request);
    }

    /**
     * 创建用户
     */
    @PostMapping("/add")
    @AuthCheck(requiredUserRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Long> userRegister(@RequestBody UserAddRequest userAddRequest) {
        ThrowUtils.throwIf(userAddRequest == null, ErrorCode.INVALID_PARAM);

        User user = new User();
        BeanUtils.copyProperties(userAddRequest, user);
        final String DEFAULT_PASSWORD = "123456";
        String encryptPassword = userService.getEncryptPassword(DEFAULT_PASSWORD);
        user.setUserPassword(encryptPassword);

        boolean result = userService.save(user);
        ThrowUtils.throwIf(!result, ErrorCode.INTERNAL_SERVER_ERROR);
        return ResultUtils.success(user.getId());
    }

    /**
     * 根据 id 查询用户（管理员）
     */
    @GetMapping("/get")
    @AuthCheck(requiredUserRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<User> getUser(long id) {
        ThrowUtils.throwIf(id <= 0, ErrorCode.INVALID_PARAM);
        User user = userService.getById(id);
        ThrowUtils.throwIf(user == null, ErrorCode.RESOURCE_NOT_FOUND);
        return ResultUtils.success(user);
    }

    /**
     * 根据 id 查询用户
     */
    @GetMapping("/get/vo")
    public BaseResponse<UserVO> getUserVO(long id) {
        BaseResponse<User> response = getUser(id);
        User user = response.getData();
        UserVO userVO = userService.getUserVO(user);
        return ResultUtils.success(userVO);
    }

    /**
     * 根据 id 删除用户
     */
    @PostMapping("/delete")
    @AuthCheck(requiredUserRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Boolean> deleteUser(@RequestBody DeleteRequest deleteRequest) {
        ThrowUtils.throwIf(deleteRequest == null || deleteRequest.getId() <= 0, ErrorCode.INVALID_PARAM);
        boolean result = userService.removeById(deleteRequest.getId());
        return ResultUtils.success(result);
    }

    /**
     * 更新用户
     */
    @PostMapping("/update")
    @AuthCheck(requiredUserRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Boolean> updateUser(@RequestBody UserUpdateRequest userUpdateRequest) {
        ThrowUtils.throwIf(userUpdateRequest == null || userUpdateRequest.getId() != 0, ErrorCode.INVALID_PARAM);
        User user = new User();
        BeanUtils.copyProperties(userUpdateRequest, user);
        boolean result = userService.updateById(user);
        ThrowUtils.throwIf(!result, ErrorCode.INTERNAL_SERVER_ERROR);
        return ResultUtils.success(true);
    }

    /**
     * 分页查询用户
     */
    @PostMapping("/list/page/vo")
    @AuthCheck(requiredUserRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Page<UserVO>> listUserVOByPage(@RequestBody UserQueryRequest userQueryRequest) {
        ThrowUtils.throwIf(userQueryRequest == null, ErrorCode.INVALID_PARAM);
        long currentPage = userQueryRequest.getCurrentPage();
        long pageSize = userQueryRequest.getPageSize();
        Page<User> userPage = userService.page(new Page<>(currentPage, pageSize), userService.getUserQueryWrapper(userQueryRequest));
        Page<UserVO> userVOPage = new Page<>(currentPage, pageSize, userPage.getTotal());
        List<UserVO> userVOList = userService.getUserVOList(userPage.getRecords());
        userVOPage.setRecords(userVOList);
        return ResultUtils.success(userVOPage);
    }
}
