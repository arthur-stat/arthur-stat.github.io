package com.arth.picloud.model.dto.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 更新用户请求数据传输对象（DTO）
 */
@Data
public class UserUpdateRequest implements Serializable {

    private static final long serialVersionUID = 8331052435600198600L;

    private Long id;

    private String userName;

    private String userAccount;

    private String userAvatar;

    private String userProfile;

    private String userRole;
}
