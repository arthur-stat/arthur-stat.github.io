package com.arth.picloud.model.dto.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 管理员创建用户账户请求数据传输对象（DTO）
 */
@Data
public class UserAddRequest implements Serializable {

    private static final long serialVersionUID = 2631175579675882663L;

    private String userName;

    private String userAccount;

    private String userAvatar;

    private String userProfile;

    private String userRole;
}