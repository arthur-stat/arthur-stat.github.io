package com.arth.picloud.common;

import lombok.Data;

@Data
public class PageRequest {

    private int currentPage;

    private int pageSize;

    private String sortField;

    private String sortOrder;
}
