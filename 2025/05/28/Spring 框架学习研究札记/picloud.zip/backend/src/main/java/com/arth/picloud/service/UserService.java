package com.arth.picloud.service;

import com.arth.picloud.model.dto.user.UserQueryRequest;
import com.arth.picloud.model.entity.User;
import com.arth.picloud.model.vo.LoginUserVO;
import com.arth.picloud.model.vo.UserVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
* @author asheo
* @description 针对表【user(用户)】的数据库操作Service
* @createDate 2025-05-18 23:44:38
*/
public interface UserService extends IService<User> {

    /**
     * 用户注册
     *
     * @param userAccount   用户账户
     * @param userPassword  用户密码
     * @param recreatePassword 确认密码
     * @return 返回用户 id
     */
    long userRegister(String userAccount, String userPassword, String recreatePassword);

    /**
     * 用户登录
     *
     * @param userAccount  用户账户
     * @param userPassword 用户密码
     * @param request HTTP Servlet
     * @return 返回用户登录状态
     */
    LoginUserVO userLogin(String userAccount, String userPassword, HttpServletRequest request);

    /**
     * 后端服务获取当前登录用户
     *
     * @param request HTTP Servlet
     * @return 当前登录用户
     */
    User getLoginUser(HttpServletRequest request);

    /**
     * 用户信息脱敏
     *
     * @param user 用户信息
     * @return 脱敏后的用户信息
     */
    LoginUserVO getLoginUserVO(User user);

    /**
     * 密码加密
     *
     * @param userPassword 用户密码
     * @return 返回加密后的密文
     */
    String getEncryptPassword(String userPassword);

    /**
     * 获取用户视图
     *
     * @param user 用户
     * @return 用户视图
     */
    UserVO getUserVO(User user);

    /**
     * 获取用户视图列表
     *
     * @param users 用户列表
     * @return 用户视图列表
     */
    List<UserVO> getUserVOList(List<User> users);

    /**
     * 用户登出
     *
     * @param request HTTP Servlet
     * @return
     */
    void userLogout(HttpServletRequest request);

    /**
     * 获取查询条件
     *
     * @param userQueryRequest 用户查询请求
     * @return 查询条件
     */
    QueryWrapper<User> getUserQueryWrapper(UserQueryRequest userQueryRequest);
}
