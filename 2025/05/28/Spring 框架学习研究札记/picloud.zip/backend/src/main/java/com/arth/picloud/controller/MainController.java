package com.arth.picloud.controller;

import com.arth.picloud.common.BaseResponse;
import com.arth.picloud.common.ResultUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class MainController {

    /**
     * 健康检查
     *
     * @return 返回成功测试响应
     */
    @GetMapping("/health")
    public BaseResponse<String> health() {
        return ResultUtils.success("OK!");
    }
}
