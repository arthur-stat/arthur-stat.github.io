package com.arth.picloud.service.impl;

import cn.hutool.core.util.StrUtil;
import com.arth.picloud.constant.UserConstant;
import com.arth.picloud.exception.ErrorCode;
import com.arth.picloud.exception.ThrowUtils;
import com.arth.picloud.model.dto.user.UserQueryRequest;
import com.arth.picloud.model.enums.UserRoleEnum;
import com.arth.picloud.model.vo.LoginUserVO;
import com.arth.picloud.model.vo.UserVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.arth.picloud.model.entity.User;
import com.arth.picloud.service.UserService;
import com.arth.picloud.mapper.UserMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author asheo
 * @description 针对表【user(用户)】的数据库操作Service实现
 * @createDate 2025-05-18 23:44:38
 */
@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    /**
     * 用户注册
     *
     * @param userAccount      用户账户
     * @param userPassword     用户密码
     * @param recreatePassword 确认密码
     * @return 返回用户 id
     */
    @Override
    public long userRegister(String userAccount, String userPassword, String recreatePassword) {

        // 1. 检验参数合法性
        ThrowUtils.throwIf(
                StrUtil.isBlank(userAccount),
                ErrorCode.INVALID_PARAM, "账号不能为空");

        ThrowUtils.throwIf(
                StrUtil.isBlank(userPassword),
                ErrorCode.INVALID_PARAM, "密码不能为空");

        ThrowUtils.throwIf(
                StrUtil.isBlank(recreatePassword),
                ErrorCode.INVALID_PARAM, "未填写确认密码");

        ThrowUtils.throwIf(
                !userPassword.equals(recreatePassword),
                ErrorCode.INVALID_PARAM, "两次输入的密码不一致");

        // 2. 判断账户是否已存在
        ThrowUtils.throwIf(
                this.lambdaQuery().eq(User::getUserAccount, userAccount).exists(),
                ErrorCode.INVALID_PARAM, "账号已被注册");

        // 3. 密码撒盐、加密
        String encryptPassword = getEncryptPassword(userPassword);

        // 4. 记录至数据库
        User user = new User();
        user.setUserAccount(userAccount);
        user.setUserPassword(encryptPassword);
        user.setUserName("新用户");
        user.setUserRole(UserRoleEnum.USER.getValue());
        boolean flag = this.save(user);
        ThrowUtils.throwIf(!flag, ErrorCode.INTERNAL_SERVER_ERROR, "系统错误，注册失败");

        return user.getId();
    }

    /**
     * 用户登录
     *
     * @param userAccount  用户账户
     * @param userPassword 用户密码
     * @param request HTTP Servlet 请求
     * @return 返回用户登录状态
     */
    @Override
    public LoginUserVO userLogin(String userAccount, String userPassword, HttpServletRequest request) {

        // 1. 检验参数合法性
        ThrowUtils.throwIf(
                StrUtil.isBlank(userAccount),
                ErrorCode.INVALID_PARAM, "账号不能为空");

        ThrowUtils.throwIf(
                StrUtil.isBlank(userPassword),
                ErrorCode.INVALID_PARAM, "密码不能为空");

        // 2. 密码加密
        String encryptPassword = getEncryptPassword(userPassword);

        // 3. 查询数据库，对比密文
        boolean accountExist = this.lambdaQuery().eq(User::getUserAccount, userAccount).exists();
        ThrowUtils.throwIf(
                !accountExist,
                ErrorCode.RESOURCE_NOT_FOUND, "账号不存在");

        User user = this.lambdaQuery().eq(User::getUserAccount, userAccount).eq(User::getUserPassword, encryptPassword).one();
        ThrowUtils.throwIf(
                user == null,
                ErrorCode.INVALID_PARAM, "密码错误");

        // 4. 返回更新后的 session
        request.getSession().setAttribute(UserConstant.USER_LOGIN_STATE, user);
        return this.getLoginUserVO(user);
    }

    /**
     * 后端服务获取当前登录用户
     *
     * @param request HTTP Servlet
     * @return 当前登录用户
     */
    public User getLoginUser(HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        ThrowUtils.throwIf(
                user == null || user.getId() == null,
                ErrorCode.NOT_LOGIN, "未登录");
        User latestUser = this.getById(user.getId());
        ThrowUtils.throwIf(
                latestUser == null,
                ErrorCode.NOT_LOGIN, "用户不存在");
        return latestUser;
    }

    /**
     * 用户登出
     *
     * @param request HTTP Servlet
     * @return
     */
    @Override
    public void userLogout(HttpServletRequest request) {
        User user = (User) request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        ThrowUtils.throwIf(
                user == null,
                ErrorCode.NOT_LOGIN, "未登录");
        request.getSession().removeAttribute(UserConstant.USER_LOGIN_STATE);
    }

    /**
     * 获取用户视图
     *
     * @param user 用户
     * @return 用户视图
     */
    @Override
    public UserVO getUserVO(User user) {
        if (user == null) return null;
        UserVO userVO = new UserVO();
        BeanUtils.copyProperties(user, userVO);
        return userVO;
    }

    /**
     * 获取用户视图列表
     *
     * @param users 用户列表
     * @return 用户视图列表
     */
    @Override
    public List<UserVO> getUserVOList(List<User> users) {
        return users.stream()
                .map(this::getUserVO)
                .collect(Collectors.toList());
    }

    /**
     * 用户信息脱敏
     *
     * @param user 用户信息
     * @return 脱敏后的用户信息
     */
    @Override
    public LoginUserVO getLoginUserVO(User user) {
        LoginUserVO loginUserVO = new LoginUserVO();
        BeanUtils.copyProperties(user, loginUserVO);
        return loginUserVO;
    }

    /**
     * 密码加密
     *
     * @param userPassword 用户密码
     * @return 返回加密后的密文
     */
    @Override
    public String getEncryptPassword(String userPassword) {
        final String salt = "666";
        return DigestUtils.md5DigestAsHex((salt + userPassword).getBytes());
    }

    /**
     * 获取查询条件
     *
     * @param userQueryRequest 用户查询请求
     * @return 查询条件
     */
    @Override
    public QueryWrapper<User> getUserQueryWrapper(UserQueryRequest userQueryRequest) {
        ThrowUtils.throwIf(
                userQueryRequest == null,
                ErrorCode.INVALID_PARAM, "空请求");
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();

        Long id = userQueryRequest.getId();
        String userName = userQueryRequest.getUserName();
        String userAccount = userQueryRequest.getUserAccount();
        String userProfile = userQueryRequest.getUserProfile();
        String userRole = userQueryRequest.getUserRole();
        String sortField = userQueryRequest.getSortField();
        String sortOrder = userQueryRequest.getSortOrder();

        queryWrapper.eq(id != null, "id", id);
        queryWrapper.like(StrUtil.isNotBlank(userName), "user_name", userName);
        queryWrapper.like(StrUtil.isNotBlank(userAccount), "user_account", userAccount);
        queryWrapper.like(StrUtil.isNotBlank(userProfile), "user_profile", userProfile);
        queryWrapper.like(StrUtil.isNotBlank(userRole), "user_role", userRole);
        if (sortField != null && !sortField.isEmpty()) {
            boolean isAsc = sortOrder == null || "ascend".equals(sortOrder);
            queryWrapper.orderBy(true, isAsc, sortField);
        }
        return queryWrapper;
    }
}
