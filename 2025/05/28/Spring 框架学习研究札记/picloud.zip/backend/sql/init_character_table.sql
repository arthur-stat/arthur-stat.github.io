-- 创建库
CREATE database IF NOT EXISTS picloud;

-- 切换库
USE picloud;

-- 角色关联表
CREATE TABLE picture_character (
    picture_id         BIGINT       NOT NULL COMMENT '关联图片 id',
    characters         VARCHAR(10)  NOT NULL COMMENT '涉及角色',

    PRIMARY KEY (picture_id, characters),
    KEY idx_character (characters),
    FOREIGN KEY (picture_id) REFERENCES picture(id) ON DELETE CASCADE
)

COMMENT '图片表的角色关联表'
COLLATE = utf8mb4_unicode_ci
ENGINE = InnoDB;