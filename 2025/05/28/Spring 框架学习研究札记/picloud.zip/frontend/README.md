# PiCloud 前端

这是PiCloud项目的前端部分，使用Vue 3 + Element Plus开发。

## 项目设置

### 安装依赖
```
npm install
```

### 开发模式启动
```
npm run serve
```

### 编译生产版本
```
npm run build
```

## 功能说明

目前实现的功能：

- 用户注册
- 用户登录/登出
- 查看个人信息
- 个人资料设置

## 目录结构

```
frontend/
  ├── public/             # 静态资源
  ├── src/                # 源代码
  │   ├── assets/         # 资源文件
  │   ├── components/     # 组件
  │   ├── router/         # 路由配置
  │   ├── store/          # 状态管理
  │   ├── utils/          # 工具函数
  │   ├── views/          # 页面视图
  │   ├── App.vue         # 根组件
  │   └── main.js         # 入口文件
  ├── .gitignore          # git忽略文件
  ├── package.json        # 项目配置
  └── README.md           # 项目说明
``` 