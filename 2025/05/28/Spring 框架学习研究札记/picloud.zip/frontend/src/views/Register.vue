<template>
  <div class="register-container">
    <el-card class="register-card">
      <div class="register-header">
        <h2>注册 PiCloud</h2>
      </div>
      
      <el-form ref="registerFormRef" :model="registerForm" :rules="registerRules" label-position="top">
        <el-form-item label="账号" prop="userAccount">
          <el-input v-model="registerForm.userAccount" placeholder="请输入账号" />
        </el-form-item>
        
        <el-form-item label="密码" prop="userPassword">
          <el-input v-model="registerForm.userPassword" type="password" placeholder="请输入密码" show-password />
        </el-form-item>
        
        <el-form-item label="确认密码" prop="recreatePassword">
          <el-input v-model="registerForm.recreatePassword" type="password" placeholder="请再次输入密码" show-password />
        </el-form-item>
        
        <el-form-item>
          <el-button type="primary" :loading="isLoading" style="width: 100%;" @click="handleRegister">
            {{ isLoading ? '注册中...' : '注册' }}
          </el-button>
        </el-form-item>
      </el-form>
      
      <div class="register-options">
        <router-link to="/login">已有账号？立即登录</router-link>
      </div>
      
      <div v-if="error" class="register-error">
        <el-alert :title="error" type="error" show-icon :closable="false" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../store/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

// 注册表单数据
const registerForm = reactive({
  userAccount: '',
  userPassword: '',
  recreatePassword: ''
})

// 密码一致性验证
const validatePassword = (rule, value, callback) => {
  if (value === '') {
    callback(new Error('请再次输入密码'))
  } else if (value !== registerForm.userPassword) {
    callback(new Error('两次输入密码不一致'))
  } else {
    callback()
  }
}

// 表单验证规则
const registerRules = {
  userAccount: [
    { required: true, message: '请输入账号', trigger: 'blur' },
    { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
  ],
  userPassword: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码长度不能小于6个字符', trigger: 'blur' }
  ],
  recreatePassword: [
    { required: true, message: '请再次输入密码', trigger: 'blur' },
    { validator: validatePassword, trigger: 'blur' }
  ]
}

// 获取store中的状态
const isLoading = computed(() => userStore.isLoading)
const error = computed(() => userStore.error)

// 表单引用
const registerFormRef = ref(null)

// 处理注册
const handleRegister = async () => {
  if (!registerFormRef.value) return
  
  try {
    await registerFormRef.value.validate()
    
    await userStore.registerUser(
      registerForm.userAccount, 
      registerForm.userPassword, 
      registerForm.recreatePassword
    )
    
    ElMessage.success('注册成功，请登录')
    router.push('/login')
  } catch (error) {
    // 错误已经在store中处理
    console.error('注册失败:', error)
  }
}
</script>

<style scoped>
.register-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f7fa;
}

.register-card {
  width: 400px;
  padding: 20px;
}

.register-header {
  text-align: center;
  margin-bottom: 30px;
}

.register-options {
  margin-top: 20px;
  text-align: center;
}

.register-error {
  margin-top: 20px;
}
</style>