<template>
  <div class="profile-container">
    <app-header />
    
    <div class="container">
      <el-row :gutter="20">
        <el-col :span="8">
          <el-card shadow="hover" class="user-card">
            <div class="user-avatar">
              <el-avatar :size="100" :src="userStore.currentUser?.userAvatar || defaultAvatar"></el-avatar>
            </div>
            <h2 class="text-center">{{ userStore.currentUser?.userName || '用户' }}</h2>
            <p class="text-center text-muted">{{ userStore.currentUser?.userAccount }}</p>
            <div class="user-meta">
              <p>角色: {{ userRoleText }}</p>
              <p>注册时间: {{ formatDate(userStore.currentUser?.createTime) }}</p>
            </div>
          </el-card>
        </el-col>
        
        <el-col :span="16">
          <el-card shadow="hover">
            <div class="profile-header">
              <h3>个人资料</h3>
            </div>
            
            <el-divider />
            
            <el-form 
              ref="profileFormRef" 
              :model="profileForm" 
              :rules="profileRules" 
              label-width="100px"
              v-loading="isLoading"
            >
              <el-form-item label="用户名" prop="userName">
                <el-input v-model="profileForm.userName" placeholder="请输入用户名"></el-input>
              </el-form-item>
              
              <el-form-item label="个人简介" prop="userProfile">
                <el-input 
                  v-model="profileForm.userProfile" 
                  type="textarea" 
                  :rows="4" 
                  placeholder="请输入个人简介"
                ></el-input>
              </el-form-item>
              
              <el-form-item label="头像">
                <div class="avatar-uploader">
                  <el-upload
                    class="avatar-uploader"
                    action="#"
                    :show-file-list="false"
                    :auto-upload="false"
                    :on-change="handleAvatarChange"
                  >
                    <el-avatar v-if="avatarUrl" :src="avatarUrl" :size="100"></el-avatar>
                    <el-button v-else type="primary">上传头像</el-button>
                  </el-upload>
                </div>
              </el-form-item>
              
              <el-form-item>
                <el-button type="primary" @click="updateProfile">保存修改</el-button>
              </el-form-item>
            </el-form>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { useUserStore } from '../store/user'
import { updateUser } from '../utils/api'
import { ElMessage } from 'element-plus'
import AppHeader from '../components/AppHeader.vue'

const userStore = useUserStore()
const defaultAvatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'

// 用户角色文本
const userRoleText = computed(() => {
  const role = userStore.currentUser?.userRole
  return role === 'admin' ? '管理员' : '普通用户'
})

// 格式化日期
const formatDate = (dateString) => {
  if (!dateString) return '-'
  const date = new Date(dateString)
  return date.toLocaleDateString('zh-CN')
}

// 表单数据
const profileForm = reactive({
  userName: '',
  userProfile: '',
  userAvatar: ''
})

// 表单规则
const profileRules = {
  userName: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
  ]
}

// 表单引用
const profileFormRef = ref(null)
const isLoading = ref(false)
const avatarUrl = ref('')

// 从store初始化表单数据
const initForm = () => {
  if (userStore.currentUser) {
    profileForm.userName = userStore.currentUser.userName || ''
    profileForm.userProfile = userStore.currentUser.userProfile || ''
    profileForm.userAvatar = userStore.currentUser.userAvatar || ''
    avatarUrl.value = profileForm.userAvatar
  }
}

// 处理头像上传
const handleAvatarChange = (file) => {
  // 这里简单处理，实际项目中应该上传到服务器
  avatarUrl.value = URL.createObjectURL(file.raw)
  profileForm.userAvatar = avatarUrl.value
}

// 更新用户资料
const updateProfile = async () => {
  if (!profileFormRef.value) return
  
  try {
    await profileFormRef.value.validate()
    
    isLoading.value = true
    
    // 准备数据
    const updateData = {
      id: userStore.currentUser.id,
      userName: profileForm.userName,
      userProfile: profileForm.userProfile,
      userAvatar: profileForm.userAvatar
    }
    
    // 调用接口
    // 注: 实际后端可能还没有实现完全的用户更新功能
    await updateUser(updateData)
    
    // 重新获取用户数据
    await userStore.fetchCurrentUser()
    
    ElMessage.success('个人资料更新成功')
  } catch (error) {
    console.error('更新失败:', error)
    ElMessage.error(error.message || '更新失败')
  } finally {
    isLoading.value = false
  }
}

onMounted(async () => {
  // 获取最新用户数据
  await userStore.fetchCurrentUser()
  initForm()
})
</script>

<style scoped>
.profile-container {
  min-height: 100vh;
  background-color: #f5f7fa;
  padding-bottom: 40px;
}

.container {
  padding-top: 30px;
}

.user-card {
  padding: 20px;
}

.user-avatar {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.user-meta {
  margin-top: 20px;
  color: #606266;
}

.profile-header {
  padding: 10px 0;
}

.text-muted {
  color: #909399;
}

.avatar-uploader {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
</style> 