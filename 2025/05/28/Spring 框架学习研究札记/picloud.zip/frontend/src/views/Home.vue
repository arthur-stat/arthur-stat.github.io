<template>
  <div class="home-container">
    <app-header />
    
    <div class="welcome-section">
      <h1>欢迎使用 PiCloud</h1>
      <p>这是一个基于云存储的应用平台</p>
    </div>
    
    <div class="container">
      <el-row :gutter="20">
        <el-col :span="24">
          <el-card shadow="hover">
            <div class="welcome-content">
              <h3>您已成功登录</h3>
              <p>后续功能正在开发中，敬请期待！</p>
            </div>
          </el-card>
        </el-col>
      </el-row>
      
      <!-- 权限测试区域 - 所有用户可见 -->
      <el-row class="mt-20">
        <el-col :span="24">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <h3>权限测试区域</h3>
              </div>
            </template>
            
            <div class="permission-test">
              <p>
                您当前的身份是: 
                <el-tag :type="userStore.isAdmin ? 'danger' : 'success'">
                  {{ userStore.isAdmin ? '管理员' : '普通用户' }}
                </el-tag>
              </p>
              
              <div class="test-buttons">
                <el-button type="primary" @click="testUserList">
                  调用获取用户列表API (需管理员权限)
                </el-button>
                
                <el-badge v-if="testResults.userList" :type="testResults.userList.success ? 'success' : 'danger'" :value="testResults.userList.success ? '成功' : '失败'">
                </el-badge>
              </div>
              
              <div v-if="testResults.userList" class="test-result">
                <el-alert
                  :title="testResults.userList.message"
                  :type="testResults.userList.success ? 'success' : 'error'"
                  :description="testResults.userList.details"
                  show-icon
                />
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
      
      <!-- 管理员专用用户列表 -->
      <el-row v-if="userStore.isAdmin" class="mt-20">
        <el-col :span="24">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <h3>用户管理（管理员专用功能）</h3>
              </div>
            </template>
            
            <el-button type="primary" @click="fetchUserList" class="mb-20">
              刷新用户列表
            </el-button>
            
            <el-table 
              v-loading="isLoading" 
              :data="userList" 
              style="width: 100%" 
              border 
              stripe
            >
              <el-table-column prop="id" label="ID" width="80" />
              <el-table-column prop="userAccount" label="账号" width="150" />
              <el-table-column prop="userName" label="用户名" width="150" />
              <el-table-column prop="userProfile" label="简介" />
              <el-table-column prop="userRole" label="角色" width="100">
                <template #default="{ row }">
                  <el-tag :type="row.userRole === 'admin' ? 'danger' : 'success'">
                    {{ row.userRole === 'admin' ? '管理员' : '用户' }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="createTime" label="创建时间" width="180">
                <template #default="{ row }">
                  {{ formatDate(row.createTime) }}
                </template>
              </el-table-column>
            </el-table>
            
            <div class="pagination-container">
              <el-pagination
                v-model:current-page="currentPage"
                v-model:page-size="pageSize"
                :page-sizes="[10, 20, 30, 50]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
              />
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useUserStore } from '../store/user'
import { getUserList } from '../utils/api'
import { ElMessage } from 'element-plus'
import AppHeader from '../components/AppHeader.vue'

const userStore = useUserStore()

// 用户列表数据
const userList = ref([])
const isLoading = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

// 测试结果状态
const testResults = reactive({
  userList: null
})

// 初始化
onMounted(() => {
  // 获取当前用户信息
  userStore.fetchCurrentUser().then(() => {
    // 如果是管理员，自动加载用户列表
    if (userStore.isAdmin) {
      fetchUserList()
    }
  })
})

// 格式化日期
const formatDate = (dateString) => {
  if (!dateString) return '-'
  const date = new Date(dateString)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

// 获取用户列表
const fetchUserList = async () => {
  isLoading.value = true
  try {
    const params = {
      currentPage: currentPage.value,
      pageSize: pageSize.value
    }
    
    const res = await getUserList(params)
    userList.value = res.data.records
    total.value = res.data.total
  } catch (error) {
    console.error('获取用户列表失败:', error)
    ElMessage.error(error.message || '获取用户列表失败，权限不足')
  } finally {
    isLoading.value = false
  }
}

// 测试用户列表权限
const testUserList = async () => {
  try {
    const params = {
      currentPage: 1,
      pageSize: 5
    }
    
    isLoading.value = true
    const res = await getUserList(params)
    
    // 请求成功
    testResults.userList = {
      success: true,
      message: '获取用户列表成功',
      details: `成功获取 ${res.data.total} 条用户数据，您具有管理员权限`
    }
  } catch (error) {
    // 请求失败
    testResults.userList = {
      success: false,
      message: '获取用户列表失败',
      details: `错误信息: ${error.message || '权限不足'}`
    }
  } finally {
    isLoading.value = false
  }
}

// 处理每页数量变化
const handleSizeChange = (val) => {
  pageSize.value = val
  fetchUserList()
}

// 处理页码变化
const handleCurrentChange = (val) => {
  currentPage.value = val
  fetchUserList()
}
</script>

<style scoped>
.home-container {
  min-height: 100vh;
  background-color: #f5f7fa;
}

.welcome-section {
  text-align: center;
  padding: 40px 0;
  background-color: #fff;
  margin-bottom: 30px;
}

.welcome-content {
  text-align: center;
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.permission-test {
  padding: 10px 0;
}

.test-buttons {
  margin: 20px 0;
  display: flex;
  align-items: center;
  gap: 10px;
}

.test-result {
  margin-top: 10px;
}

.mb-20 {
  margin-bottom: 20px;
}

.mt-20 {
  margin-top: 20px;
}
</style> 