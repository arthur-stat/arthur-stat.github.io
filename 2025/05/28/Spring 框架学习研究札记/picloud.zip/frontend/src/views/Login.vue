<template>
  <div class="login-container">
    <el-card class="login-card">
      <div class="login-header">
        <h2>登录 PiCloud</h2>
      </div>
      
      <el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" label-position="top">
        <el-form-item label="账号" prop="userAccount">
          <el-input v-model="loginForm.userAccount" placeholder="请输入账号" />
        </el-form-item>
        
        <el-form-item label="密码" prop="userPassword">
          <el-input v-model="loginForm.userPassword" type="password" placeholder="请输入密码" show-password />
        </el-form-item>
        
        <el-form-item>
          <el-button type="primary" :loading="isLoading" style="width: 100%;" @click="handleLogin">
            {{ isLoading ? '登录中...' : '登录' }}
          </el-button>
        </el-form-item>
      </el-form>
      
      <div class="login-options">
        <router-link to="/register">还没有账号？立即注册</router-link>
      </div>
      
      <div v-if="error" class="login-error">
        <el-alert :title="error" type="error" show-icon :closable="false" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../store/user'
import { ElMessage } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

// 登录表单数据
const loginForm = reactive({
  userAccount: '',
  userPassword: ''
})

// 表单验证规则
const loginRules = {
  userAccount: [
    { required: true, message: '请输入账号', trigger: 'blur' }
  ],
  userPassword: [
    { required: true, message: '请输入密码', trigger: 'blur' }
  ]
}

// 获取store中的状态
const isLoading = computed(() => userStore.isLoading)
const error = computed(() => userStore.error)

// 表单引用
const loginFormRef = ref(null)

// 处理登录
const handleLogin = async () => {
  if (!loginFormRef.value) return
  
  try {
    await loginFormRef.value.validate()
    
    await userStore.loginUser(loginForm.userAccount, loginForm.userPassword)
    ElMessage.success('登录成功')
    router.push('/')
  } catch (error) {
    // 错误已经在store中处理
    console.error('登录失败:', error)
  }
}
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f7fa;
}

.login-card {
  width: 400px;
  padding: 20px;
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.login-options {
  margin-top: 20px;
  text-align: center;
}

.login-error {
  margin-top: 20px;
}
</style> 