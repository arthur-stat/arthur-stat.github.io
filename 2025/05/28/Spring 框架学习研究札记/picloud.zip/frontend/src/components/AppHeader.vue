<template>
  <header class="app-header">
    <div class="container">
      <div class="header-content">
        <div class="logo">
          <router-link to="/">
            <h1>PiCloud</h1>
          </router-link>
        </div>
        
        <div class="menu">
          <el-menu
            mode="horizontal"
            :ellipsis="false"
            background-color="transparent"
            text-color="#333"
            active-text-color="#409EFF"
            :router="true"
          >
            <el-menu-item index="/">首页</el-menu-item>
          </el-menu>
        </div>
        
        <div class="user-actions">
          <template v-if="userStore.isLoggedIn">
            <el-dropdown @command="handleCommand">
              <span class="user-dropdown">
                <el-avatar :size="30" :src="userStore.currentUser?.userAvatar || defaultAvatar"></el-avatar>
                <span class="user-name">{{ userStore.currentUser?.userName || '用户' }}</span>
              </span>
              
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="profile">
                    <el-icon><user /></el-icon>
                    个人资料
                  </el-dropdown-item>
                  <el-dropdown-item divided command="logout">
                    <el-icon><switch-button /></el-icon>
                    退出登录
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
          
          <template v-else>
            <div class="auth-buttons">
              <router-link to="/login">
                <el-button>登录</el-button>
              </router-link>
              <router-link to="/register">
                <el-button type="primary">注册</el-button>
              </router-link>
            </div>
          </template>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup>
import { useUserStore } from '../store/user'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { User, SwitchButton } from '@element-plus/icons-vue'

const userStore = useUserStore()
const router = useRouter()
const defaultAvatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'

// 下拉菜单选择处理
const handleCommand = (command) => {
  if (command === 'profile') {
    router.push('/profile')
  } else if (command === 'logout') {
    ElMessageBox.confirm('确认退出登录？', '提示', {
      confirmButtonText: '确认',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async () => {
      try {
        // 调用登出API
        const result = await userStore.logoutUser()
        // 登出成功，显示成功消息
        ElMessage.success(result.message || '已退出登录')
        // 跳转到登录页
        router.push('/login')
      } catch (error) {
        // 登出失败，但我们仍需要返回登录页
        ElMessage.error(error.message || '登出失败')
        // 即使后端登出失败，也清除前端状态并跳转登录页
        userStore.currentUser = null
        router.push('/login')
      }
    }).catch(() => {
      // 用户取消退出操作，不做任何处理
    })
  }
}
</script>

<style scoped>
.app-header {
  background-color: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  position: sticky;
  top: 0;
  z-index: 100;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  height: 60px;
}

.logo h1 {
  margin: 0;
  font-size: 24px;
  color: #409EFF;
}

.logo a {
  text-decoration: none;
}

.user-dropdown {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.user-name {
  margin-left: 8px;
  font-size: 14px;
}

.auth-buttons {
  display: flex;
  gap: 10px;
}

.menu {
  flex-grow: 1;
  margin-left: 20px;
}

.user-actions {
  margin-left: 20px;
}
</style> 