import { defineStore } from 'pinia'
import { login, register, logout, getCurrentUser } from '../utils/api'

export const useUserStore = defineStore('user', {
  state: () => ({
    currentUser: null,
    isLoading: false,
    error: null
  }),

  getters: {
    isLoggedIn: (state) => !!state.currentUser,
    isAdmin: (state) => state.currentUser?.userRole === 'admin'
  },

  actions: {
    // 登录
    async loginUser(userAccount, userPassword) {
      this.isLoading = true
      this.error = null
      try {
        const result = await login({ userAccount, userPassword })
        this.currentUser = result.data
        return result
      } catch (err) {
        this.error = err.message || '登录失败'
        throw err
      } finally {
        this.isLoading = false
      }
    },

    // 注册
    async registerUser(userAccount, userPassword, recreatePassword) {
      this.isLoading = true
      this.error = null
      try {
        const result = await register({ userAccount, userPassword, recreatePassword })
        return result
      } catch (err) {
        this.error = err.message || '注册失败'
        throw err
      } finally {
        this.isLoading = false
      }
    },

    // 登出
    async logoutUser() {
      this.isLoading = true
      this.error = null
      try {
        // 调用登出API，如果成功则会返回自定义的成功响应
        // 如果失败，会抛出异常并进入catch块
        const result = await logout()
        
        // 登出成功，清除用户状态
        this.currentUser = null
        return result
      } catch (err) {
        // 登出请求失败
        this.error = err.message || '登出失败'
        // 重新抛出错误，让UI层处理
        throw err
      } finally {
        this.isLoading = false
      }
    },

    // 获取当前用户
    async fetchCurrentUser() {
      this.isLoading = true
      this.error = null
      try {
        const result = await getCurrentUser()
        this.currentUser = result.data
        return result
      } catch (err) {
        this.error = err.message || '获取用户信息失败'
        this.currentUser = null
      } finally {
        this.isLoading = false
      }
    },

    // 清除错误信息
    clearError() {
      this.error = null
    }
  }
}) 