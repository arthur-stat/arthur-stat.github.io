import axios from 'axios'

// 创建axios实例
const api = axios.create({
  baseURL: 'http://localhost:8848/api', // 添加/api前缀
  timeout: 10000,
  withCredentials: true // 跨域请求时携带cookie
})

// 请求拦截器
api.interceptors.request.use(
  config => {
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// 响应拦截器
api.interceptors.response.use(
  response => {
    // 处理logout特殊情况 - 后端不返回数据但状态码为200表示成功
    if (response.config.url.includes('/user/logout') && response.status === 200) {
      // 无响应体 + 状态码200 = 登出成功
      return { code: 0, data: null, message: '登出成功' }
    }
    
    const res = response.data
    // 根据后端约定的错误码判断请求是否成功
    if (res.code !== 0) {
      // 请求失败，抛出错误信息
      const errorMsg = res.message || res.data || '请求失败'
      return Promise.reject(new Error(errorMsg))
    } else {
      // 请求成功，返回结果
      return res
    }
  },
  error => {
    // 网络错误、超时、后端返回4xx/5xx状态码等
    return Promise.reject(error)
  }
)

// 用户登录
export function login(data) {
  return api({
    url: '/user/login',
    method: 'post',
    data
  })
}

// 用户注册
export function register(data) {
  return api({
    url: '/user/register',
    method: 'post',
    data
  })
}

// 用户登出
export function logout() {
  return api({
    url: '/user/logout',
    method: 'post'
  })
}

// 获取当前登录用户
export function getCurrentUser() {
  return api({
    url: '/user/get/login',
    method: 'get'
  })
}

// 更新用户信息
export function updateUser(data) {
  return api({
    url: '/user/update',
    method: 'post',
    data
  })
}

// 分页查询用户（管理员功能）
export function getUserList(data) {
  return api({
    url: '/user/list/page/vo',
    method: 'post',
    data
  })
}

export default api
