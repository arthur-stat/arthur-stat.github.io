# 最小化编译

Windows 11 24H2 AMD64
Go1.23.4

```cmd
set CGO_ENABLED=0
```

```cmd
go build -ldflags="-s -w" -o music_info.exe ./...
```

# 软件说明

指定正确的路径后，将在当前目录下生成metadata.json与music_info.txt。

metadata.json为目标文件夹下歌曲文件的常用元数据，music_info.txt则只提取标题、专辑、专辑艺术家与发表年份，并以自然语言形式写入。