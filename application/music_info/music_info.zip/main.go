// arthur-stat, 2025

package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/dhowden/tag"
)

type TrackMetadata struct {
	FilePath    string  `json:"file_path"`
	Title       string  `json:"title"`
	Artist      string  `json:"artist"`
	AlbumArtist string  `json:"album_artist"`
	Composer    string  `json:"composer"`
	Album       string  `json:"album"`
	Date        string  `json:"date"`
	Year        int     `json:"year"`
	Codec       string  `json:"codec"`
	FileSizeMB  float32 `json:"file_size_mb"`
	ModifiedAt  string  `json:"modified_at"`
	Format      string  `json:"format"`
	FileType    string  `json:"file_type"`
}

func main() {
	fmt.Println("本程序将对指定文件夹路径下及其子目录内的歌曲抓取元数据信息。\n- 完全支持：flac\n- 已知无法提取元数据：mp3, m4a, ape\n- 未测试：alac, ogg, mp3")
	folderPath := getInputPath()

	txtFile, err := os.Create("music_info.txt")
	if err != nil {
		fmt.Printf("无法输出文件: %v\n", err)
		return
	}
	defer txtFile.Close()

	var jsonData []TrackMetadata

	filepath.Walk(folderPath, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() || !isSupportedFile(path) {
			return nil
		}

		if meta := collectMetadata(path); meta != nil {
			// 写入自然语言
			txtLine := fmt.Sprintf("标题：%s，专辑艺术家：%s，专辑：%s，年份：%d\n",
				meta.Title, meta.AlbumArtist, meta.Album, meta.Year)
			if _, err := txtFile.WriteString(txtLine); err != nil {
				fmt.Printf("文件写入失败: %v\n", err)
			}

			// 写入JSON
			jsonData = append(jsonData, *meta)
		}
		return nil
	})

	if err := saveAsJSON(jsonData); err != nil {
		fmt.Printf("JSON保存失败: %v\n", err)
		return
	}
}

func saveAsJSON(data []TrackMetadata) error {
	file, err := os.Create("metadata.json")
	if err != nil {
		return err
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	encoder.SetIndent("", "  ")
	return encoder.Encode(map[string]interface{}{
		"generated_at": time.Now().Format(time.RFC3339),
		"file_count":   len(data),
		"metadata":     data,
	})
}

func getInputPath() string {
	var inputPath string
	var err error
	scanner := bufio.NewScanner(os.Stdin)
	fmt.Print("目标文件夹路径（回车使用当前目录）: ")
	for {
		if !scanner.Scan() {
			fmt.Println("\n输入流异常")
			os.Exit(1)
		}

		inputPath = inputPathProcessor(scanner.Text())
		if _, err = os.Stat(inputPath); err == nil {
			return inputPath
		} else if inputPath == "exit" {
			os.Exit(0)
		}

		switch {
		case os.IsNotExist(err):
			fmt.Printf("⚠️ 路径 %s 不存在\n", inputPath)
		case os.IsPermission(err):
			fmt.Printf("⚠️ 访问路径 %s 被拒绝\n", inputPath)
		default:
			fmt.Printf("⚠️ 尝试访问路径时发生系统异常：%v\n", err)
		}

		fmt.Print("重试，或输入exit退出程序：")
	}
}

func inputPathProcessor(input string) string {
	processedInput := strings.TrimSpace(input)
	if processedInput == "" {
		dir, err := os.Getwd()
		if err != nil {
			fmt.Printf("⚠️ 无法获取当前目录：%v\n", err)
			os.Exit(1)
		}
		return dir
	}

	if processedInput[0] == '"' || processedInput[0] == '\'' {
		processedInput = processedInput[1:]
	}
	inputLen := len(processedInput)
	if processedInput[inputLen-1] == '"' || processedInput[inputLen-1] == '\'' {
		processedInput = processedInput[:inputLen-1]
	}

	return processedInput
}

func isSupportedFile(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	_, ok := map[string]bool{
		".flac": true, ".mp3": true, ".m4a": true, ".ogg": true, ".mp4": true, ".alac": true,
	}[ext]
	return ok
}

func collectMetadata(path string) *TrackMetadata {
	file, err := os.Open(path)
	if err != nil {
		fmt.Printf("无法打开文件 %s: %v\n", path, err)
		return nil
	}
	defer file.Close()

	var meta tag.Metadata
	fileExt := strings.ToLower(filepath.Ext(path))

	switch fileExt {
	case ".ape": // 待处理
		meta = nil
	default:
		if m, err := tag.ReadFrom(file); err == nil {
			meta = m
		}
	}

	if meta == nil {
		fmt.Printf("无法解析歌曲 %s 的元数据\n", path)
		return nil
	}

	stat, _ := file.Stat()
	fileSize := (float32)(stat.Size()) / 1024 / 1024
	modified := stat.ModTime().Format(time.RFC3339)

	date, year := sanitizeDateAndYear(meta)

	// META
	return &TrackMetadata{
		FilePath:    path,
		Title:       sanitizeString(meta.Title()),
		Artist:      sanitizeString(meta.Artist()),
		AlbumArtist: sanitizeString(meta.AlbumArtist()),
		Composer:    sanitizeString(meta.Composer()),
		Album:       sanitizeString(meta.Album()),
		Date:        date,
		Year:        year,
		Codec:       strings.ToUpper(fileExt[1:]),
		FileSizeMB:  fileSize,
		ModifiedAt:  modified,
		Format:      sanitizeString((string)(meta.Format())),
		FileType:    sanitizeString((string)(meta.FileType())),
	}
}

func sanitizeString(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return "unknown"
	}
	return s
}

func sanitizeDateAndYear(m tag.Metadata) (string, int) {
	var date string
	var year int
	year = m.Year()

	if dateValues, ok := m.Raw()["date"]; ok {
		date = dateValues.(string)
		if year <= 1 && len(date) >= 4 {
			year, _ = strconv.Atoi(date[0:4])
		}
		return date, year
	} else {
		date = "unknown"
		if year <= 1 && len(date) >= 4 {
			return date, -1
		}
		return date, year
	}
}
