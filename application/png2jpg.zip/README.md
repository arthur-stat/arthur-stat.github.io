aaa.ps1是Windows下PowerShell的批处理脚本，其中内容只有执行aaa_convert.py。如果需要查看打印信息，则在脚本末尾加上一行`pause`。

aaa_convert.py是逻辑处理Python脚本。

aaa_config.py中只存放了参数：

- input_folder：目标路径
- output_folder：输出（子）路径，如果为空则输出至目标路径，否则输出至指定子路径
- input_resolution：原图片分辨率
- output_resolution：目标分辨率
- compaction_quality：压缩质量，范围在0至100之间
- clear_original_files：是否在转换后删除原文件，值为True或False
- exception：例外情况，忽略指定的原图片，不进行任何操作

其实input_resolution与output_resolution不需要严格与图片的实际分辨率一致，因为处理逻辑实际上是根据`output_resolution[0]/input_resolution[0]`计算放缩比例，然后按比例放缩的。所以，例如希望将图片的长宽均缩小一半，令`"input_resolution": [2]`、`"output_resolution": [1]`即可。