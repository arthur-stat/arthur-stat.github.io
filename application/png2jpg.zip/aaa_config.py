SETTINGS = {
    "input_folder": "E:\\blog\\source\\_posts\\计算机网络",  # 输入文件夹
    "output_folder": "",                                    # 输出文件夹
    "input_resolution": (2560, 1440),                       # 源分辨率
    "output_resolution": (1920, 1080),                      # 目的分辨率
    "compaction_quality": 90,                               # 压缩质量
    "clear_original_files": True,                           # 是否清理源图片
    "exception": ["1745627731406.png"]                      # 例外
}