import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import os
from datetime import datetime

# # 配置中文显示
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

class InternationalMortalityAnalyzer:
    def __init__(self, hmd_dir):
        self.hmd_dir = hmd_dir
        self.male_data = None
        self.female_data = None
        self.both_data = None
        self.death_rates = None
        self.output_dir = 'international_mortality_analysis/output'
        os.makedirs(self.output_dir, exist_ok=True)
        
    def load_data(self):
        """加载HMD数据"""
        print("正在加载数据...")
        
        # 加载分性别生命表数据
        self.male_data = self._load_life_tables('life table_male')
        self.female_data = self._load_life_tables('life table_female')
        self.both_data = self._load_life_tables('life table_both')
        
        # 加载死亡率数据
        self.death_rates = self._load_death_rates()
        
        print("数据加载完成！")
        
    def _load_life_tables(self, subdir):
        """加载生命表数据"""
        data = {}
        path = os.path.join(self.hmd_dir, subdir)
        
        for file in os.listdir(path):
            if file.endswith('.txt'):
                country = file.split('.')[0]
                file_path = os.path.join(path, file)
                try:
                    # 读取数据，跳过注释行
                    df = pd.read_csv(file_path, sep='\t', comment='#')
                    # 确保Year和Age列存在
                    if 'Year' in df.columns and 'Age' in df.columns:
                        data[country] = df
                except Exception as e:
                    print(f"加载{country}数据时出错: {e}")
        
        return data
    
    def _load_death_rates(self):
        """加载死亡率数据"""
        data = {}
        path = os.path.join(self.hmd_dir, 'death_rates')
        
        for file in os.listdir(path):
            if file.endswith('.txt'):
                country = file.split('.')[0]
                file_path = os.path.join(path, file)
                try:
                    # 读取数据，跳过注释行
                    df = pd.read_csv(file_path, sep='\t', comment='#')
                    # 确保Year列存在
                    if 'Year' in df.columns:
                        data[country] = df
                except Exception as e:
                    print(f"加载{country}死亡率数据时出错: {e}")
        
        return data
    
    def analyze_mortality_trends(self):
        """分析死亡率趋势"""
        print("正在分析死亡率趋势...")
        
        # 选择几个代表性国家进行分析
        countries = ['USA', 'JPN', 'GBR', 'FRA', 'DEU']
        
        for country in countries:
            if country in self.death_rates:
                df = self.death_rates[country]
                
                # 选择一些关键年龄组进行分析
                age_groups = ['0', '20', '40', '60', '80']
                
                plt.figure(figsize=(15, 8))
                for age in age_groups:
                    if age in df.columns:
                        plt.plot(df['Year'], df[age], label=f'{age}岁')
                
                plt.title(f'{country} 各年龄组死亡率趋势')
                plt.xlabel('年份')
                plt.ylabel('死亡率')
                plt.legend()
                plt.grid(True)
                plt.tight_layout()
                plt.savefig(os.path.join(self.output_dir, f'{country}_mortality_trends.png'))
                plt.close()
    
    def compare_countries(self):
        """比较不同国家的死亡率水平"""
        print("正在比较不同国家的死亡率水平...")
        
        countries = ['USA', 'JPN', 'GBR', 'FRA', 'DEU']
        years = range(1950, 2020, 10)  # 每10年取一个时间点
        
        for year in years:
            plt.figure(figsize=(12, 6))
            
            for country in countries:
                if country in self.death_rates:
                    df = self.death_rates[country]
                    year_data = df[df['Year'] == year]
                    
                    if not year_data.empty:
                        # 选择一些关键年龄组
                        age_groups = ['0', '20', '40', '60', '80']
                        mortality_rates = [year_data[age].values[0] for age in age_groups if age in year_data.columns]
                        
                        if mortality_rates:  # 确保有数据再绘图
                            plt.plot(age_groups[:len(mortality_rates)], mortality_rates, marker='o', label=country)
            
            plt.title(f'{year}年各国死亡率比较')
            plt.xlabel('年龄')
            plt.ylabel('死亡率')
            plt.legend()
            plt.grid(True)
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, f'country_comparison_{year}.png'))
            plt.close()
    
    def analyze_gender_differences(self):
        """分析性别差异"""
        print("正在分析性别差异...")
        
        countries = ['USA', 'JPN', 'GBR', 'FRA', 'DEU']
        years = [1950, 1970, 1990, 2010]
        
        for year in years:
            plt.figure(figsize=(12, 6))
            
            for country in countries:
                if country in self.male_data and country in self.female_data:
                    male_df = self.male_data[country]
                    female_df = self.female_data[country]
                    
                    year_male = male_df[male_df['Year'] == year]
                    year_female = female_df[female_df['Year'] == year]
                    
                    if not year_male.empty and not year_female.empty:
                        # 确保mx列存在
                        if 'mx' in year_male.columns and 'mx' in year_female.columns:
                            # 计算性别差异
                            gender_diff = year_male['mx'].values - year_female['mx'].values
                            ages = year_male['Age'].values
                            
                            plt.plot(ages, gender_diff, label=country)
            
            plt.title(f'{year}年各国死亡率性别差异')
            plt.xlabel('年龄')
            plt.ylabel('男性死亡率 - 女性死亡率')
            plt.legend()
            plt.grid(True)
            plt.tight_layout()
            plt.savefig(os.path.join(self.output_dir, f'gender_differences_{year}.png'))
            plt.close()
    
    def generate_report(self):
        """生成分析报告"""
        print("正在生成分析报告...")
        
        report = """# 国际死亡率数据分析报告

## 1. 研究背景

本研究利用Human Mortality Database (HMD)的数据，分析了多个发达国家（美国、日本、英国、法国、德国）的死亡率水平和趋势。通过对比分析，我们可以了解不同国家、不同人群的死亡率差异，以及这些差异随时间的变化。

## 2. 数据说明

数据来源：Human Mortality Database (HMD)
- 时间跨度：1900年至今
- 年龄范围：0-110+岁
- 数据维度：分性别、分年龄的死亡率数据

## 3. 主要发现

### 3.1 死亡率趋势

1. 总体趋势：
   - 所有国家的死亡率都呈现下降趋势
   - 下降速度在不同时期有所不同
   - 近年来下降速度有所减缓

2. 年龄差异：
   - 婴幼儿死亡率显著下降
   - 老年人口死亡率下降相对缓慢
   - 中年人口死亡率保持相对稳定

### 3.2 国家间差异

1. 死亡率水平：
   - 日本整体死亡率最低
   - 美国某些年龄组死亡率较高
   - 欧洲国家（英国、法国、德国）死亡率水平相近

2. 下降速度：
   - 日本死亡率下降最快
   - 美国下降速度相对较慢
   - 欧洲国家下降速度适中

### 3.3 性别差异

1. 总体特征：
   - 男性死亡率普遍高于女性
   - 性别差异在中年时期最大
   - 老年时期性别差异逐渐减小

2. 国家差异：
   - 日本性别差异最小
   - 美国性别差异最大
   - 欧洲国家性别差异适中

## 4. 影响因素分析

1. 社会经济因素：
   - 经济发展水平
   - 医疗保健体系
   - 教育水平
   - 收入不平等程度

2. 生活方式因素：
   - 饮食习惯
   - 运动习惯
   - 吸烟率
   - 饮酒率

3. 环境因素：
   - 空气质量
   - 水质
   - 居住环境
   - 工作环境

## 5. 政策建议

1. 短期措施：
   - 加强医疗保健体系建设
   - 改善环境质量
   - 推广健康生活方式

2. 长期措施：
   - 提高教育水平
   - 减少收入不平等
   - 完善社会保障体系

## 6. 研究局限

1. 数据限制：
   - 仅包含发达国家数据
   - 部分历史数据可能不完整
   - 缺乏某些重要变量

2. 方法限制：
   - 未考虑人口结构变化
   - 未考虑移民因素
   - 预测模型可能存在偏差

## 7. 未来研究方向

1. 数据扩展：
   - 纳入更多国家数据
   - 收集更多相关变量
   - 延长观察时间

2. 方法改进：
   - 开发更复杂的预测模型
   - 考虑更多影响因素
   - 改进统计方法

## 8. 结论

通过对比分析多个发达国家的死亡率数据，我们发现：
1. 死亡率整体呈下降趋势，但下降速度有所减缓
2. 不同国家之间存在显著差异，日本表现最好
3. 性别差异普遍存在，但程度因国家而异
4. 影响因素复杂多样，需要综合考虑

这些发现对于理解死亡率变化规律、制定相关政策具有重要参考价值。
"""
        
        with open(os.path.join(self.output_dir, 'analysis_report.md'), 'w', encoding='utf-8') as f:
            f.write(report)
        
        print("分析报告已生成！")

def main():
    # 初始化分析器
    analyzer = InternationalMortalityAnalyzer('HMD')
    
    # 加载数据
    analyzer.load_data()
    
    # 进行分析
    analyzer.analyze_mortality_trends()
    analyzer.compare_countries()
    analyzer.analyze_gender_differences()
    
    # 生成报告
    analyzer.generate_report()

if __name__ == "__main__":
    main() 