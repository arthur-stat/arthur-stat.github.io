import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import os
from datetime import datetime
import logging
import re

# 配置日志
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')

# # 配置中文显示
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

class MortalityDataAnalyzer:
    def __init__(self, hmd_dir):
        self.hmd_dir = hmd_dir
        self.data = {}
        self.output_dir = 'international_mortality_analysis/eda_output'
        os.makedirs(self.output_dir, exist_ok=True)
        logging.info(f"初始化分析器，数据目录：{hmd_dir}")
        
    def load_data(self):
        """加载标准化后的HMD死亡率数据（Mx_1x1_std）"""
        logging.info("开始加载标准化数据...")
        
        if not os.path.exists(self.hmd_dir):
            logging.error(f"数据目录不存在：{self.hmd_dir}")
            return
        
        for file in os.listdir(self.hmd_dir):
            if file.endswith('.Mx_1x1.txt'):
                match = re.match(r'([A-Z]{3,}(_[A-Z]+)?)(\.Mx_1x1)?\.txt', file)
                if match:
                    country = match.group(1)
                    file_path = os.path.join(self.hmd_dir, file)
                    try:
                        logging.info(f"正在加载 {country} 数据: {file_path}")
                        df = pd.read_csv(file_path, sep='\t', skiprows=2)
                        df.columns = df.columns.str.strip()
                        required_cols = ['Year', 'Age', 'Female', 'Male', 'Total']
                        if all(col in df.columns for col in required_cols):
                            df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
                            df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
                            for col in ['Female', 'Male', 'Total']:
                                df[col] = pd.to_numeric(df[col], errors='coerce')
                            df = df.dropna()
                            df = df[df['Age'] <= 100]
                            self.data[country] = df
                            logging.info(f"成功加载 {country} 数据，形状：{df.shape}")
                        else:
                            missing_cols = [col for col in required_cols if col not in df.columns]
                            logging.warning(f"{country} 数据缺少必要的列：{missing_cols}")
                    except Exception as e:
                        logging.error(f"加载 {country} 数据时出错: {e}")
        
        if not self.data:
            logging.error("没有成功加载任何数据！")
        else:
            logging.info(f"数据加载完成！共加载 {len(self.data)} 个国家的数据")
    
    def calculate_statistics(self):
        """计算基本统计指标"""
        logging.info("开始计算统计指标...")
        
        if not self.data:
            logging.error("没有数据可供分析！")
            return {}
            
        stats_results = {}
        
        for country, df in self.data.items():
            logging.info(f"正在计算 {country} 的统计指标...")
            
            country_stats = {
                '总体统计': {},
                '年龄组统计': {},
                '时间趋势': {}
            }
            
            # 1. 总体统计
            for col in ['Female', 'Male', 'Total']:
                rates = df[col].replace(0, np.nan)
                if rates.notna().any():
                    country_stats['总体统计'][col] = {
                        '均值': rates.mean(),
                        '中位数': rates.median(),
                        '标准差': rates.std(),
                        '最小值': rates.min(),
                        '最大值': rates.max(),
                        '变异系数': rates.std() / rates.mean() if rates.mean() != 0 else np.nan
                    }
            
            # 2. 年龄组统计
            age_groups = [0, 20, 40, 60, 80]
            for year in df['Year'].unique():
                year_data = df[df['Year'] == year]
                year_stats = {}
                for age in age_groups:
                    age_data = year_data[year_data['Age'] == age]
                    if not age_data.empty:
                        year_stats[age] = {
                            'Female': age_data['Female'].iloc[0],
                            'Male': age_data['Male'].iloc[0],
                            'Total': age_data['Total'].iloc[0]
                        }
                if year_stats:
                    country_stats['年龄组统计'][year] = year_stats
            
            # 3. 时间趋势
            for col in ['Female', 'Male', 'Total']:
                rates = df[col].replace(0, np.nan)
                if rates.notna().any():
                    # 计算年度变化率
                    changes = rates.pct_change()
                    country_stats['时间趋势'][col] = {
                        '平均年变化率': changes.mean(),
                        '变化率标准差': changes.std(),
                        '最大年增长': changes.max(),
                        '最大年下降': changes.min()
                    }
            
            stats_results[country] = country_stats
            logging.info(f"{country} 统计指标计算完成")
        
        return stats_results
    
    def visualize_trends(self, stats_results):
        """可视化死亡率趋势"""
        logging.info("开始生成可视化图表...")
        
        if not stats_results:
            logging.error("没有统计结果可供可视化！")
            return
            
        for country, stats in stats_results.items():
            if country not in self.data:
                continue
                
            logging.info(f"正在为 {country} 生成可视化图表...")
            df = self.data[country]
            
            # 1. 死亡率随年龄变化趋势
            plt.figure(figsize=(12, 6))
            years = [1950, 1970, 1990, 2010]
            for year in years:
                if year in df['Year'].values:
                    year_data = df[df['Year'] == year]
                    plt.plot(year_data['Age'], year_data['Total'], marker='o', label=str(year))
            
            plt.title(f'{country} 不同年份死亡率随年龄变化趋势')
            plt.xlabel('年龄')
            plt.ylabel('死亡率')
            plt.legend()
            plt.grid(True)
            plt.yscale('log')  # 使用对数刻度更好地显示差异
            plt.savefig(os.path.join(self.output_dir, f'{country}_age_trends.png'))
            plt.close()
            
            # 2. 死亡率随时间变化趋势
            plt.figure(figsize=(12, 6))
            ages = [0, 20, 40, 60, 80]
            for age in ages:
                age_data = df[df['Age'] == age]
                if not age_data.empty:
                    plt.plot(age_data['Year'], age_data['Total'], label=f'{age}岁')
            
            plt.title(f'{country} 不同年龄组死亡率随时间变化趋势')
            plt.xlabel('年份')
            plt.ylabel('死亡率')
            plt.legend()
            plt.grid(True)
            plt.yscale('log')
            plt.savefig(os.path.join(self.output_dir, f'{country}_time_trends.png'))
            plt.close()
            
            # 3. 性别差异对比
            plt.figure(figsize=(12, 6))
            years = [1950, 1970, 1990, 2010]
            for year in years:
                if year in df['Year'].values:
                    year_data = df[df['Year'] == year]
                    plt.plot(year_data['Age'], year_data['Male'] / year_data['Female'], 
                            marker='o', label=str(year))
            
            plt.title(f'{country} 不同年份男女死亡率比值随年龄变化趋势')
            plt.xlabel('年龄')
            plt.ylabel('男/女死亡率比值')
            plt.legend()
            plt.grid(True)
            plt.savefig(os.path.join(self.output_dir, f'{country}_gender_ratio.png'))
            plt.close()
            
            logging.info(f"{country} 可视化图表生成完成")
    
    def generate_report(self, stats_results):
        """生成分析报告"""
        logging.info("开始生成分析报告...")
        
        if not stats_results:
            logging.error("没有统计结果可供生成报告！")
            return
            
        report = """# 国际死亡率数据探索性分析报告

## 1. 数据概览

本报告基于Human Mortality Database (HMD)的数据，对多个国家的死亡率数据进行了探索性分析。分析内容包括基本统计指标、时间趋势和年龄特征等。

## 2. 统计指标分析

"""
        
        for country, stats in stats_results.items():
            report += f"\n### {country}\n\n"
            
            # 总体统计
            report += "#### 2.1 总体统计\n\n"
            report += "| 性别 | 均值 | 中位数 | 标准差 | 最小值 | 最大值 | 变异系数 |\n"
            report += "|------|------|--------|--------|--------|--------|----------|\n"
            
            for gender, metrics in stats['总体统计'].items():
                report += f"| {gender} | {metrics['均值']:.6f} | {metrics['中位数']:.6f} | "
                report += f"{metrics['标准差']:.6f} | {metrics['最小值']:.6f} | "
                report += f"{metrics['最大值']:.6f} | {metrics['变异系数']:.6f} |\n"
            
            # 时间趋势
            report += "\n#### 2.2 时间趋势\n\n"
            report += "| 性别 | 平均年变化率 | 变化率标准差 | 最大年增长 | 最大年下降 |\n"
            report += "|------|--------------|--------------|------------|------------|\n"
            
            for gender, metrics in stats['时间趋势'].items():
                report += f"| {gender} | {metrics['平均年变化率']:.6f} | "
                report += f"{metrics['变化率标准差']:.6f} | {metrics['最大年增长']:.6f} | "
                report += f"{metrics['最大年下降']:.6f} |\n"
        
        report += """
## 3. 可视化分析

通过生成的可视化图表，我们可以观察到：

1. 死亡率随年龄变化趋势：
   - 婴幼儿期死亡率较高
   - 青少年期死亡率最低
   - 老年期死亡率呈指数增长

2. 死亡率随时间变化趋势：
   - 整体呈下降趋势
   - 不同年龄组下降速度不同
   - 近年来下降速度有所减缓

3. 性别差异：
   - 男性死亡率普遍高于女性
   - 性别差异在不同年龄组表现不同
   - 性别差异随时间有所变化

## 4. 主要发现

1. 年龄特征：
   - 死亡率随年龄增长呈指数上升
   - 不同年龄组死亡率变化特征不同
   - 老年人口死亡率变化最为显著

2. 时间特征：
   - 长期来看死亡率呈下降趋势
   - 下降速度在不同时期有所不同
   - 近年来下降速度有所减缓

3. 性别特征：
   - 男性死亡率普遍高于女性
   - 性别差异在不同年龄组表现不同
   - 性别差异随时间有所变化

## 5. 建议

1. 数据收集：
   - 建议收集更多国家的数据
   - 增加更多相关变量
   - 提高数据质量

2. 分析方法：
   - 考虑更多影响因素
   - 使用更复杂的统计模型
   - 加强预测能力

3. 政策建议：
   - 关注老年人口健康
   - 加强医疗体系建设
   - 改善环境质量
"""
        
        with open(os.path.join(self.output_dir, 'eda_report.md'), 'w', encoding='utf-8') as f:
            f.write(report)
        
        logging.info("分析报告生成完成！")

def main():
    # 初始化分析器，切换到标准化目录
    analyzer = MortalityDataAnalyzer('HMD/death_rates/Mx_1x1_std')
    analyzer.load_data()
    stats_results = analyzer.calculate_statistics()
    analyzer.visualize_trends(stats_results)
    analyzer.generate_report(stats_results)

if __name__ == "__main__":
    main() 