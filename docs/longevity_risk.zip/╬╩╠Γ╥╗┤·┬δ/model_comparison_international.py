import pandas as pd
import numpy as np
from scipy.optimize import minimize
from scipy.linalg import svd
import matplotlib.pyplot as plt
import os
import logging
from datetime import datetime
import matplotlib as mpl

# # 配置中文显示
# plt.rcParams['font.sans-serif'] = ['SimHei']
# plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

# 配置日志
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(levelname)s - %(message)s')

class MortalityModelComparison:
    def __init__(self, hmd_dir):
        self.hmd_dir = hmd_dir
        self.data = {}
        self.output_dir = 'international_mortality_analysis/model_comparison_output'
        os.makedirs(self.output_dir, exist_ok=True)
        
    def load_data(self):
        """加载HMD死亡率数据"""
        logging.info("开始加载数据...")
        
        if not os.path.exists(self.hmd_dir):
            logging.error(f"数据目录不存在：{self.hmd_dir}")
            return
            
        for file in os.listdir(self.hmd_dir):
            if file.endswith('.Mx_1x1.txt'):
                country = file.split('.')[0]
                file_path = os.path.join(self.hmd_dir, file)
                try:
                    df = pd.read_csv(file_path, sep='\t', skiprows=2)
                    df.columns = df.columns.str.strip()
                    required_cols = ['Year', 'Age', 'Female', 'Male', 'Total']
                    if all(col in df.columns for col in required_cols):
                        df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
                        df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
                        for col in ['Female', 'Male', 'Total']:
                            df[col] = pd.to_numeric(df[col], errors='coerce')
                        df = df.dropna()
                        df = df[df['Age'] <= 100]
                        self.data[country] = df
                        logging.info(f"成功加载 {country} 数据")
                except Exception as e:
                    logging.error(f"加载 {country} 数据时出错: {e}")
    
    def fit_gompertz_makeham(self, mortality_rates, ages, years):
        """拟合Gompertz-Makeham模型"""
        try:
            def objective(params):
                a, b, c, d = params
                # 为每个年龄组计算预测值
                predicted = np.zeros_like(mortality_rates)
                for i, age in enumerate(ages):
                    predicted[i] = c + a * np.exp(b * age) + d * np.mean(years)
                return np.sum((mortality_rates - predicted) ** 2)
            
            # 初始参数猜测
            initial_params = [0.0001, 0.1, 0.0001, 0.0001]
            bounds = [(0, None), (0, None), (0, None), (-0.1, 0.1)]
            
            result = minimize(objective, initial_params, bounds=bounds, method='L-BFGS-B')
            return result.x
        except Exception as e:
            logging.error(f"Gompertz-Makeham模型拟合失败: {e}")
            return None
    
    def fit_lee_carter(self, mortality_matrix):
        """拟合Lee-Carter模型"""
        try:
            # 添加小常数避免取对数时出现零值
            mortality_matrix = mortality_matrix + 1e-10
            
            # 计算年龄和时间效应
            log_mx = np.log(mortality_matrix)
            ax = np.mean(log_mx, axis=1)
            centered_log_mx = log_mx - ax[:, np.newaxis]
            
            # SVD分解
            U, S, V = svd(centered_log_mx, full_matrices=False)
            
            # 提取参数
            bx = U[:, 0]
            kt = S[0] * V[0, :]
            
            return ax, bx, kt
        except Exception as e:
            logging.error(f"Lee-Carter模型拟合失败: {e}")
            return None, None, None
    
    def predict_lee_carter(self, ax, bx, kt, years):
        """使用Lee-Carter模型预测死亡率"""
        if ax is None or bx is None or kt is None:
            return None
            
        try:
            # 预测kt
            kt_mean = np.mean(kt)
            kt_std = np.std(kt)
            predicted_kt = kt_mean + (years - years[0]) * kt_std
            
            # 计算预测死亡率
            predicted_log_mx = ax[:, np.newaxis] + np.outer(bx, predicted_kt)
            predicted_mx = np.exp(predicted_log_mx)
            
            return predicted_mx
        except Exception as e:
            logging.error(f"Lee-Carter模型预测失败: {e}")
            return None
    
    def predict_gompertz_makeham(self, params, ages, years):
        """使用Gompertz-Makeham模型预测死亡率"""
        if params is None:
            return None
        try:
            a, b, c, d = params
            predicted = np.zeros((len(ages), len(years)))
            for i, age in enumerate(ages):
                for j, year in enumerate(years):
                    predicted[i, j] = c + a * np.exp(b * age) + d * year
            return predicted
        except Exception as e:
            logging.error(f"Gompertz-Makeham模型预测失败: {e}")
            return None
    
    def evaluate_models(self, country, gender='Total'):
        """评估两个模型的表现"""
        logging.info(f"开始评估 {country} 的模型表现...")
        
        if country not in self.data:
            logging.error(f"找不到 {country} 的数据")
            return None
            
        df = self.data[country]
        
        # 准备数据
        years = df['Year'].unique()
        ages = df['Age'].unique()
        
        # 创建死亡率矩阵
        mortality_matrix = df.pivot(index='Age', columns='Year', values=gender).values
        
        # 分割训练集和验证集
        train_years = years[:-5]  # 使用除最后5年外的所有数据作为训练集
        val_years = years[-5:]    # 最后5年作为验证集
        
        train_matrix = mortality_matrix[:, :len(train_years)]
        val_matrix = mortality_matrix[:, len(train_years):]
        
        # 拟合Gompertz-Makeham模型
        # 使用训练集的平均死亡率
        train_mean_rates = np.mean(train_matrix, axis=1)
        gompertz_params = self.fit_gompertz_makeham(train_mean_rates, ages, train_years)
        
        # 拟合Lee-Carter模型
        ax, bx, kt = self.fit_lee_carter(train_matrix)
        
        # 预测
        gompertz_pred = self.predict_gompertz_makeham(gompertz_params, ages, val_years)
        lee_carter_pred = self.predict_lee_carter(ax, bx, kt, val_years)
        
        # 计算评估指标
        results = {}
        
        if gompertz_pred is not None:
            gompertz_mse = np.mean((val_matrix - gompertz_pred) ** 2)
            gompertz_mae = np.mean(np.abs(val_matrix - gompertz_pred))
            gompertz_r2 = 1 - np.sum((val_matrix - gompertz_pred) ** 2) / np.sum((val_matrix - np.mean(val_matrix)) ** 2)
            results['Gompertz-Makeham'] = {
                'MSE': gompertz_mse,
                'MAE': gompertz_mae,
                'R2': gompertz_r2
            }
            
        if lee_carter_pred is not None:
            lee_carter_mse = np.mean((val_matrix - lee_carter_pred) ** 2)
            lee_carter_mae = np.mean(np.abs(val_matrix - lee_carter_pred))
            lee_carter_r2 = 1 - np.sum((val_matrix - lee_carter_pred) ** 2) / np.sum((val_matrix - np.mean(val_matrix)) ** 2)
            results['Lee-Carter'] = {
                'MSE': lee_carter_mse,
                'MAE': lee_carter_mae,
                'R2': lee_carter_r2
            }
            
        # 绘制比较图
        self.plot_comparison(country, gender, val_matrix, gompertz_pred, lee_carter_pred, val_years, ages)
        
        return results
    
    def plot_comparison(self, country, gender, actual, gompertz_pred, lee_carter_pred, years, ages):
        """绘制模型比较图"""
        plt.figure(figsize=(15, 10))
        
        # 选择几个代表性年龄组进行展示
        age_groups = [0, 20, 40, 60, 80]
        age_indices = [np.where(ages == age)[0][0] for age in age_groups]
        
        for i, age_idx in enumerate(age_indices):
            plt.subplot(len(age_groups), 1, i+1)
            plt.plot(years, actual[age_idx, :], 'k-', label='实际值')
            
            if gompertz_pred is not None:
                plt.plot(years, gompertz_pred[age_idx, :], 'r--', label='Gompertz-Makeham预测')
            if lee_carter_pred is not None:
                plt.plot(years, lee_carter_pred[age_idx, :], 'b--', label='Lee-Carter预测')
                
            plt.title(f'{country} - {gender} - {ages[age_idx]}岁')
            plt.legend()
            plt.grid(True)
            
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, f'{country}_{gender}_model_compare.png'))
        plt.close()
    
    def generate_report(self, results):
        """生成比较报告"""
        logging.info("开始生成比较报告...")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(self.output_dir, f'model_comparison_report_{timestamp}.md')
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# 死亡率模型比较报告\n\n")
            
            for country, country_results in results.items():
                f.write(f"## {country}\n\n")
                
                if not country_results:
                    f.write("模型评估失败\n\n")
                    continue
                    
                f.write("### 评估指标\n\n")
                f.write("| 模型 | MSE | MAE | R² |\n")
                f.write("|------|-----|-----|-----|\n")
                
                for model_name, metrics in country_results.items():
                    f.write(f"| {model_name} | {metrics['MSE']:.6f} | {metrics['MAE']:.6f} | {metrics['R2']:.6f} |\n")
                
                f.write("\n### 结论\n\n")
                
                # 比较两个模型的性能
                if 'Gompertz-Makeham' in country_results and 'Lee-Carter' in country_results:
                    gompertz_mse = country_results['Gompertz-Makeham']['MSE']
                    lee_carter_mse = country_results['Lee-Carter']['MSE']
                    
                    if gompertz_mse < lee_carter_mse:
                        f.write(f"在{country}的数据上，Gompertz-Makeham模型表现更好，MSE降低了{(lee_carter_mse-gompertz_mse)/lee_carter_mse*100:.2f}%\n\n")
                    else:
                        f.write(f"在{country}的数据上，Lee-Carter模型表现更好，MSE降低了{(gompertz_mse-lee_carter_mse)/gompertz_mse*100:.2f}%\n\n")
                
                f.write("\n---\n\n")
        
        logging.info(f"比较报告已生成：{report_file}")
        return report_file

def main():
    # 初始化比较器
    comparator = MortalityModelComparison('HMD/death_rates/Mx_1x1_std')
    
    # 加载数据
    comparator.load_data()
    
    # 评估每个国家的模型
    results = {}
    for country in comparator.data.keys():
        results[country] = comparator.evaluate_models(country)
    
    # 生成报告
    report_file = comparator.generate_report(results)
    logging.info(f"模型比较完成，报告已生成：{report_file}")

if __name__ == "__main__":
    main() 