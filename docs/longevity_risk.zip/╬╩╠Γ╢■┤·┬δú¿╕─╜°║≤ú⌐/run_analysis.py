"""
主执行脚本：2025年保险人口死亡率预测分析
运行完整的分析流程，包括预测和验证
"""

import sys
import os
import pandas as pd
import numpy as np
from mortality_predictor import MortalityPredictor
from model_validation import ModelValidator

def main():
    print("="*70)
    print("2025年保险人口死亡率预测分析系统")
    print("Lee-Carter + Gompertz-Makeham + 曲线修匀 + 120岁外推")
    print("="*70)
    
    # 检查数据文件是否存在
    data_file = "../【选题1数据】某保险产品死亡率.xlsx"
    if not os.path.exists(data_file):
        print(f"错误：找不到数据文件 {data_file}")
        print("请确保数据文件在正确的位置。")
        return
    
    try:
        print("\n第一阶段：死亡率预测建模")
        print("-" * 40)
        
        # 初始化预测器
        predictor = MortalityPredictor(data_file)
        
        # 运行完整分析
        results_df = predictor.run_complete_analysis()
        
        # 添加验证：检查2021年预测准确性
        print("\n验证阶段：检查模型在2021年数据上的表现")
        print("-" * 50)
        
        # 获取2021年实际数据
        actual_data = predictor.df[predictor.df['观察年度'] == 2021]
        
        for gender in ['M', 'F']:
            print(f"\n{gender}性 2021年验证:")
            gender_data = actual_data[actual_data['性别'] == gender]
            
            if gender in predictor.predictions_2025:
                pred_data = predictor.predictions_2025[gender]
                ages = pred_data['ages']
                
                # 比较关键年龄点
                key_ages = [30, 40, 50, 60, 70, 80, 90]
                
                print("年龄 | 实际2021 | LC预测 | GM预测 | 组合预测 | 修匀预测 | LC误差% | 组合误差% | 修匀误差%")
                print("-" * 90)
                
                for age in key_ages:
                    if age in ages:
                        # 找到对应的实际值
                        actual_row = gender_data[gender_data['到达年龄'] == age]
                        if not actual_row.empty:
                            actual_mort = actual_row['死亡率'].iloc[0]
                            
                            # 找到预测值
                            idx = np.where(ages == age)[0][0]
                            lc_pred = pred_data['mortality_lc'][idx] if 'mortality_lc' in pred_data else np.nan
                            gm_pred = np.nan
                            if predictor.gompertz_params[gender] is not None:
                                gm_pred = predictor.gompertz_makeham(age, *predictor.gompertz_params[gender]['params'])
                            combined_pred = pred_data['mortality_combined'][idx] if 'mortality_combined' in pred_data else np.nan
                            smooth_pred = pred_data['mortality_smoothed'][idx] if 'mortality_smoothed' in pred_data else np.nan
                            
                            # 计算误差
                            lc_error = ((lc_pred - actual_mort) / actual_mort * 100) if not np.isnan(lc_pred) else np.nan
                            combined_error = ((combined_pred - actual_mort) / actual_mort * 100) if not np.isnan(combined_pred) else np.nan
                            smooth_error = ((smooth_pred - actual_mort) / actual_mort * 100) if not np.isnan(smooth_pred) else np.nan
                            
                            print(f"{age:3d}  | {actual_mort:.6f} | {lc_pred:.6f} | {gm_pred:.6f} | {combined_pred:.6f} | {smooth_pred:.6f} | {lc_error:6.1f} | {combined_error:7.1f} | {smooth_error:7.1f}")
                
                # 计算整体误差统计
                valid_ages = []
                lc_errors = []
                combined_errors = []
                smooth_errors = []
                
                for age in range(int(ages.min()), int(ages.max()) + 1):
                    if age in ages:
                        actual_row = gender_data[gender_data['到达年龄'] == age]
                        if not actual_row.empty:
                            actual_mort = actual_row['死亡率'].iloc[0]
                            idx = np.where(ages == age)[0][0]
                            
                            lc_pred = pred_data['mortality_lc'][idx]
                            combined_pred = pred_data['mortality_combined'][idx]
                            smooth_pred = pred_data['mortality_smoothed'][idx]
                            
                            lc_error = abs((lc_pred - actual_mort) / actual_mort * 100)
                            combined_error = abs((combined_pred - actual_mort) / actual_mort * 100)
                            smooth_error = abs((smooth_pred - actual_mort) / actual_mort * 100)
                            
                            valid_ages.append(age)
                            lc_errors.append(lc_error)
                            combined_errors.append(combined_error)
                            smooth_errors.append(smooth_error)
                
                if len(lc_errors) > 0:
                    print(f"\n误差统计 (平均绝对百分比误差):")
                    print(f"  Lee-Carter:  {np.mean(lc_errors):.1f}%")
                    print(f"  组合模型:    {np.mean(combined_errors):.1f}%") 
                    print(f"  修匀模型:    {np.mean(smooth_errors):.1f}%")
                    
                    print(f"\n最大误差:")
                    max_lc_idx = np.argmax(lc_errors)
                    max_combined_idx = np.argmax(combined_errors)
                    max_smooth_idx = np.argmax(smooth_errors)
                    
                    print(f"  Lee-Carter:  {lc_errors[max_lc_idx]:.1f}% (年龄{valid_ages[max_lc_idx]})")
                    print(f"  组合模型:    {combined_errors[max_combined_idx]:.1f}% (年龄{valid_ages[max_combined_idx]})")
                    print(f"  修匀模型:    {smooth_errors[max_smooth_idx]:.1f}% (年龄{valid_ages[max_smooth_idx]})")
        
        print("\n第二阶段：模型验证与合理性分析")
        print("-" * 40)
        
        # 初始化验证器
        validator = ModelValidator(predictor)
        
        # 运行完整验证
        validation_report = validator.run_full_validation()
        
        print("\n第三阶段：结果汇总")
        print("-" * 40)
        
        # 生成汇总报告
        generate_summary_report(predictor, validator, results_df)
        
        print("\n分析完成！")
        print("="*70)
        print("输出文件：")
        print("  - mortality_predictions_2025.csv: 完整预测结果")
        print("  - validation_report.txt: 模型验证报告")
        print("  - summary_report.txt: 汇总分析报告")
        print("  - 各类可视化图表 (.png文件)")
        print("="*70)
        
        # 显示关键结果预览
        show_key_results(results_df, predictor)
        
    except Exception as e:
        print(f"分析过程中出现错误: {str(e)}")
        import traceback
        traceback.print_exc()


def generate_summary_report(predictor, validator, results_df):
    """生成汇总分析报告"""
    print("生成汇总分析报告...")
    
    report = []
    report.append("="*70)
    report.append("2025年保险人口死亡率预测分析汇总报告")
    report.append("="*70)
    
    # 1. 项目概述
    report.append("\n一、项目概述")
    report.append("-" * 30)
    report.append("预测目标：2025年分性别、分年龄死亡率")
    report.append("外推范围：0-120岁")
    report.append("使用方法：Lee-Carter模型 + Gompertz-Makeham模型 + 曲线修匀")
    report.append("数据来源：某保险产品死亡率数据(2010-2021)")
    
    # 2. 数据概况
    report.append("\n二、数据概况")
    report.append("-" * 30)
    df = predictor.df
    report.append(f"数据规模：{df.shape[0]}条记录")
    report.append(f"年龄范围：{df['到达年龄'].min()}-{df['到达年龄'].max()}岁")
    report.append(f"观察年度：{df['观察年度'].min()}-{df['观察年度'].max()}年")
    report.append(f"性别分布：男性{len(df[df['性别']=='M'])}条，女性{len(df[df['性别']=='F'])}条")
    
    # 3. 模型参数
    report.append("\n三、主要模型参数")
    report.append("-" * 30)
    
    for gender in ['M', 'F']:
        if gender in predictor.lee_carter_params:
            lc_params = predictor.lee_carter_params[gender]
            report.append(f"\n{gender}性Lee-Carter模型:")
            report.append(f"  k(t)趋势斜率: {predictor.predictions_2025[gender]['trend_slope']:.6f}")
            report.append(f"  预测k(2025): {predictor.predictions_2025[gender]['kt_2025']:.6f}")
            
        if predictor.gompertz_params[gender] is not None:
            gm_params = predictor.gompertz_params[gender]['params']
            report.append(f"\n{gender}性Gompertz-Makeham模型:")
            report.append(f"  参数A (基础死亡率): {gm_params[0]:.6f}")
            report.append(f"  参数B (年龄相关基数): {gm_params[1]:.6f}")
            report.append(f"  参数C (衰老速率): {gm_params[2]:.6f}")
            report.append(f"  模型R²: {predictor.gompertz_params[gender]['r_squared']:.4f}")
    
    # 4. 关键预测结果
    report.append("\n四、关键预测结果")
    report.append("-" * 30)
    
    for gender in ['M', 'F']:
        ext_data = predictor.extrapolated_120[gender]
        mortality = ext_data['mortality']
        
        report.append(f"\n{gender}性关键年龄预测死亡率:")
        key_ages = [30, 50, 65, 80, 100, 120]
        for age in key_ages:
            if age < len(mortality):
                report.append(f"  {age}岁: {mortality[age]:.6f}")
    
    # 5. 模型质量评估
    report.append("\n五、模型质量评估")
    report.append("-" * 30)
    
    if 'performance' in validator.validation_results:
        for gender in ['M', 'F']:
            if gender in validator.validation_results['performance']:
                perf = validator.validation_results['performance'][gender]
                report.append(f"\n{gender}性模型性能:")
                report.append(f"  Lee-Carter R²: {perf['lee_carter']['r_squared']:.4f}")
                if 'gompertz_makeham' in perf:
                    report.append(f"  Gompertz-Makeham R²: {perf['gompertz_makeham']['r_squared']:.4f}")
    
    # 6. 合理性检查
    report.append("\n六、合理性检查结果")
    report.append("-" * 30)
    
    if 'plausibility' in validator.validation_results:
        for gender in ['M', 'F']:
            if gender in validator.validation_results['plausibility']:
                plaus = validator.validation_results['plausibility'][gender]
                report.append(f"\n{gender}性:")
                
                if 'monotonicity_30plus' in plaus:
                    mono_ratio = plaus['monotonicity_30plus']
                    status = "良好" if mono_ratio > 0.95 else "需关注"
                    report.append(f"  单调性检查: {mono_ratio:.2%} ({status})")
                
                report.append(f"  120岁死亡率: {plaus['max_mortality_120']:.6f}")
                
                # 国际对比
                if 'international_comparison' in plaus:
                    report.append("  国际对比结果:")
                    for age_label, data in plaus['international_comparison'].items():
                        age = age_label.split('_')[1]
                        ratio = data['ratio']
                        status = "合理" if 0.5 <= ratio <= 2.0 else "偏离"
                        report.append(f"    {age}岁预测/国际参考: {ratio:.2f} ({status})")
    
    # 7. 应用建议
    report.append("\n七、应用建议与风险提示")
    report.append("-" * 30)
    report.append("\n应用场景:")
    report.append("  ✓ 养老年金产品定价")
    report.append("  ✓ 保险准备金评估")
    report.append("  ✓ 长寿风险管理")
    report.append("  ✓ 监管报告编制")
    
    report.append("\n风险提示:")
    report.append("  ⚠ 保险人口选择效应可能影响预测准确性")
    report.append("  ⚠ 医疗技术进步可能改变死亡率趋势")
    report.append("  ⚠ 外推至120岁的不确定性较大")
    report.append("  ⚠ 极端事件(如疫情)可能显著影响死亡率")
    
    report.append("\n使用建议:")
    report.append("  1. 定期更新模型以反映最新数据")
    report.append("  2. 结合外部研究调整预测结果")
    report.append("  3. 建立预测区间量化不确定性")
    report.append("  4. 监控实际结果与预测的偏差")
    
    # 8. 技术说明
    report.append("\n八、技术方法说明")
    report.append("-" * 30)
    report.append("\nLee-Carter模型:")
    report.append("  公式: ln(m(x,t)) = a(x) + b(x)×k(t)")
    report.append("  用途: 捕捉死亡率的时间趋势")
    report.append("  优势: 国际标准方法，理论成熟")
    
    report.append("\nGompertz-Makeham模型:")
    report.append("  公式: μ(x) = A + B×exp(C×x)")
    report.append("  用途: 建模成年人死亡率的年龄模式")
    report.append("  优势: 生物学基础扎实，适合外推")
    
    report.append("\n曲线修匀技术:")
    report.append("  方法: Whittaker-Henderson修匀")
    report.append("  用途: 消除随机波动，确保平滑性")
    report.append("  优势: 保证单调性和连续性")
    
    # 保存报告
    with open('Task 2/summary_report.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(report))
    
    print("汇总报告已保存到 Task 2/summary_report.txt")


def show_key_results(results_df, predictor):
    """显示关键结果预览"""
    print("\n关键结果预览:")
    print("="*50)
    
    # 显示几个关键年龄的预测结果
    key_ages = [30, 50, 65, 80, 100, 120]
    
    print("2025年预测死亡率:")
    print("-" * 30)
    print("年龄    男性(M)       女性(F)")
    print("-" * 30)
    
    for age in key_ages:
        m_rate = results_df[(results_df['性别'] == 'M') & (results_df['年龄'] == age)]
        f_rate = results_df[(results_df['性别'] == 'F') & (results_df['年龄'] == age)]
        
        if not m_rate.empty and not f_rate.empty:
            m_val = m_rate['2025年预测死亡率'].iloc[0]
            f_val = f_rate['2025年预测死亡率'].iloc[0]
            print(f"{age:3d}    {m_val:.6f}    {f_val:.6f}")
    
    print("-" * 30)
    
    # 显示模型质量摘要
    print("\n模型质量摘要:")
    print("-" * 20)
    for gender in ['M', 'F']:
        if gender in predictor.lee_carter_params:
            # 计算一个简单的质量指标
            data_years = len(predictor.mortality_matrix[gender].columns)
            data_ages = len(predictor.mortality_matrix[gender].index)
            
            print(f"{gender}性数据: {data_ages}个年龄 × {data_years}年")
            
            if predictor.gompertz_params[gender] is not None:
                r2 = predictor.gompertz_params[gender]['r_squared']
                print(f"      Gompertz-Makeham R² = {r2:.3f}")


if __name__ == "__main__":
    main() 