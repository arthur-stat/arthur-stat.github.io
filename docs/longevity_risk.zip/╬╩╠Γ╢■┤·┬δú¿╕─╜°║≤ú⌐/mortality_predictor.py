"""
2025年保险人口死亡率预测系统
实现Lee-Carter模型 + Gompertz-Makeham模型 + 曲线修匀
外推至120岁
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate
from scipy.optimize import curve_fit
from scipy.interpolate import UnivariateSpline, splrep, splev
from scipy.ndimage import gaussian_filter1d
from sklearn.metrics import mean_squared_error, mean_absolute_error
import warnings
import os
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class MortalityPredictor:
    def __init__(self, data_path):
        """
        初始化死亡率预测器
        
        Parameters:
        data_path: str, Excel文件路径
        """
        self.data_path = data_path
        self.df = None
        self.mortality_matrix = {}
        self.lee_carter_params = {}
        self.gompertz_params = {}
        self.predictions_2025 = {}
        self.extrapolated_120 = {}
        
    def load_and_prepare_data(self):
        """加载并预处理数据"""
        print("正在加载和预处理数据...")
        
        # 读取数据
        self.df = pd.read_excel(self.data_path, sheet_name='data')
        
        # 计算死亡率
        self.df['死亡率'] = self.df['理赔数'] / self.df['暴露数']
        
        # 处理异常值：死亡率>0.5视为异常
        self.df.loc[self.df['死亡率'] > 0.5, '死亡率'] = np.nan
        
        # 基本统计信息
        print(f"数据形状: {self.df.shape}")
        print(f"年龄范围: {self.df['到达年龄'].min()} - {self.df['到达年龄'].max()}")
        print(f"观察年度: {self.df['观察年度'].min()} - {self.df['观察年度'].max()}")
        print(f"死亡率范围: {self.df['死亡率'].min():.6f} - {self.df['死亡率'].max():.6f}")
        
        # 为每个性别创建死亡率矩阵
        for gender in ['M', 'F']:
            gender_data = self.df[self.df['性别'] == gender]
            matrix = gender_data.pivot(index='到达年龄', columns='观察年度', values='死亡率')
            
            # 处理缺失值：线性插值
            matrix = matrix.interpolate(method='linear', axis=1)
            matrix = matrix.interpolate(method='linear', axis=0)
            
            # 确保没有零值（对数变换需要）
            matrix = matrix.fillna(method='ffill').fillna(method='bfill')
            matrix[matrix <= 0] = 1e-6
            
            self.mortality_matrix[gender] = matrix
            
        print("数据预处理完成！")
        
    def lee_carter_fit(self, gender):
        """
        Lee-Carter模型拟合
        
        Parameters:
        gender: str, 'M' 或 'F'
        
        Returns:
        dict: 包含a(x), b(x), k(t)参数
        """
        matrix = self.mortality_matrix[gender].values
        ages = self.mortality_matrix[gender].index.values
        years = self.mortality_matrix[gender].columns.values
        
        # Step 1: 计算a(x) - 平均对数死亡率
        log_mort = np.log(matrix)
        ax = np.mean(log_mort, axis=1)
        
        # Step 2: 中心化矩阵
        centered_matrix = log_mort - ax.reshape(-1, 1)
        
        # Step 3: SVD分解
        U, s, Vt = np.linalg.svd(centered_matrix, full_matrices=False)
        
        # Step 4: 提取第一主成分
        bx = U[:, 0]
        kt = s[0] * Vt[0, :]
        
        # 标准化以确保可识别性
        # 约束: sum(b(x)) = 1, k(t0) = 0
        bx = bx / np.sum(bx)
        kt = kt - kt[0]
        
        return {
            'ax': ax,
            'bx': bx, 
            'kt': kt,
            'ages': ages,
            'years': years
        }
    
    def predict_kt_2025(self, kt_historical, years):
        """
        预测2025年的k(t)值
        使用更保守的方法，限制外推幅度
        """
        # 简单线性趋势拟合
        coeffs = np.polyfit(years, kt_historical, 1)
        slope, intercept = coeffs
        
        # 预测2025年，但限制变化幅度
        kt_2025_raw = slope * 2025 + intercept
        
        # 保守限制：相比最近3年平均值，变化不超过30%
        recent_kt_mean = np.mean(kt_historical[-3:])
        max_change = recent_kt_mean * 0.3
        
        if kt_2025_raw > recent_kt_mean + max_change:
            kt_2025 = recent_kt_mean + max_change
            print(f"    k(t)预测值被限制: 原始{kt_2025_raw:.3f} -> 调整{kt_2025:.3f}")
        elif kt_2025_raw < recent_kt_mean - max_change:
            kt_2025 = recent_kt_mean - max_change
            print(f"    k(t)预测值被限制: 原始{kt_2025_raw:.3f} -> 调整{kt_2025:.3f}")
        else:
            kt_2025 = kt_2025_raw
        
        return kt_2025, slope
    
    def gompertz_makeham(self, x, A, B, C):
        """Gompertz-Makeham模型函数"""
        return A + B * np.exp(C * x)
    
    def fit_gompertz_makeham(self, ages, mortality_rates, age_range=(30, 90)):
        """
        拟合Gompertz-Makeham模型
        只对30-90岁年龄段拟合
        """
        # 选择拟合年龄范围
        mask = (ages >= age_range[0]) & (ages <= age_range[1])
        fit_ages = ages[mask]
        fit_rates = mortality_rates[mask]
        
        # 去除可能的异常值
        valid_mask = (fit_rates > 0) & (fit_rates < 1) & np.isfinite(fit_rates)
        fit_ages = fit_ages[valid_mask]
        fit_rates = fit_rates[valid_mask]
        
        if len(fit_ages) < 10:  # 确保有足够的数据点
            return None
            
        try:
            # 设置合理的参数边界
            bounds = ([0, 1e-6, 0], [0.1, 1, 0.2])
            popt, pcov = curve_fit(
                self.gompertz_makeham, 
                fit_ages, 
                fit_rates,
                bounds=bounds,
                maxfev=5000
            )
            
            # 计算拟合质量
            predicted = self.gompertz_makeham(fit_ages, *popt)
            r_squared = 1 - np.sum((fit_rates - predicted) ** 2) / np.sum((fit_rates - np.mean(fit_rates)) ** 2)
            
            return {
                'params': popt,
                'covariance': pcov,
                'r_squared': r_squared,
                'fit_ages': fit_ages,
                'fit_rates': fit_rates
            }
        except:
            return None
    
    def whittaker_henderson_smooth(self, y, lambda_param=1000):
        """保守的修匀方法，避免负值和过度平滑"""
        n = len(y)
        if n < 3:
            return y
        
        # 使用移动平均进行温和修匀，保持原有形状
        smoothed = np.copy(y)
        
        # 对于年龄0-10，使用简单移动平均
        for i in range(1, min(10, n-1)):
            window_size = 3
            start_idx = max(0, i - window_size//2)
            end_idx = min(n, i + window_size//2 + 1)
            smoothed[i] = np.mean(y[start_idx:end_idx])
        
        # 对于年龄10以上，使用加权移动平均，更多保留原始值
        for i in range(10, n-1):
            # 5点加权移动平均，中心点权重更大
            weights = np.array([0.1, 0.2, 0.4, 0.2, 0.1])
            start_idx = max(0, i - 2)
            end_idx = min(n, i + 3)
            
            if end_idx - start_idx == 5:
                smoothed[i] = np.average(y[start_idx:end_idx], weights=weights)
            else:
                # 边界情况，使用简单平均
                smoothed[i] = np.mean(y[start_idx:end_idx])
        
        # 确保非负性
        smoothed = np.maximum(smoothed, 1e-6)
        
        # 确保修匀后的值不会偏离原值太多（最多±50%）
        ratio_bounds = (0.5, 1.5)
        for i in range(n):
            ratio = smoothed[i] / y[i] if y[i] > 0 else 1.0
            if ratio < ratio_bounds[0]:
                smoothed[i] = y[i] * ratio_bounds[0]
            elif ratio > ratio_bounds[1]:
                smoothed[i] = y[i] * ratio_bounds[1]
        
        return smoothed
    
    def predict_2025_mortality(self):
        """预测2025年死亡率"""
        print("正在预测2025年死亡率...")
        
        for gender in ['M', 'F']:
            print(f"\n处理{gender}性数据...")
            
            # Lee-Carter模型拟合
            lc_params = self.lee_carter_fit(gender)
            self.lee_carter_params[gender] = lc_params
            
            print(f"  Lee-Carter参数: k(t)范围 {lc_params['kt'].min():.3f} - {lc_params['kt'].max():.3f}")
            print(f"  年龄范围: {lc_params['ages'].min()} - {lc_params['ages'].max()}")
            
            # 预测2025年的k(t)
            kt_2025, trend_slope = self.predict_kt_2025(lc_params['kt'], lc_params['years'])
            print(f"  k(2025)预测值: {kt_2025:.3f}, 趋势斜率: {trend_slope:.3f}")
            
            # 计算2025年死亡率（Lee-Carter）
            log_mort_2025_lc = lc_params['ax'] + lc_params['bx'] * kt_2025
            mort_2025_lc = np.exp(log_mort_2025_lc)
            
            print(f"  Lee-Carter 2025预测死亡率范围: {mort_2025_lc.min():.6f} - {mort_2025_lc.max():.6f}")
            
            # 获取2021年数据用于Gompertz-Makeham拟合
            mort_2021 = self.mortality_matrix[gender][2021].values
            ages = lc_params['ages']
            
            print(f"  实际2021年死亡率范围: {mort_2021.min():.6f} - {mort_2021.max():.6f}")
            
            # 显示关键年龄的2021实际值 vs Lee-Carter预测值对比
            key_ages = [30, 50, 70, 80, 90]
            print(f"  关键年龄2021实际 vs Lee-Carter 2025预测对比:")
            for key_age in key_ages:
                if key_age in ages:
                    idx = np.where(ages == key_age)[0][0]
                    real_2021 = mort_2021[idx]
                    pred_lc = mort_2025_lc[idx]
                    print(f"    {key_age}岁: 实际2021={real_2021:.6f}, LC 2025={pred_lc:.6f}, 比值={pred_lc/real_2021:.3f}")
            
            # Gompertz-Makeham模型拟合
            gm_result = self.fit_gompertz_makeham(ages, mort_2021)
            
            if gm_result is not None:
                self.gompertz_params[gender] = gm_result
                print(f"  Gompertz-Makeham拟合成功, R²={gm_result['r_squared']:.4f}")
                print(f"  GM参数: A={gm_result['params'][0]:.8f}, B={gm_result['params'][1]:.8f}, C={gm_result['params'][2]:.6f}")
                
                # 计算2025年死亡率（Gompertz-Makeham）
                # 使用趋势调整而不是直接使用2021年参数
                A, B, C = gm_result['params']
                
                # 简单趋势调整：基于死亡率改善趋势
                # 假设死亡率以每年1-2%的速度改善
                improvement_rate = 0.015  # 1.5%年改善率
                years_ahead = 2025 - 2021
                trend_factor = (1 - improvement_rate) ** years_ahead
                
                # 调整参数A和B（保持C不变，因为它反映衰老速率）
                A_2025 = A * trend_factor
                B_2025 = B * trend_factor
                
                print(f"  GM趋势调整: 改善率={improvement_rate:.1%}/年, 调整因子={trend_factor:.3f}")
                print(f"  GM 2025参数: A={A_2025:.8f}, B={B_2025:.8f}, C={C:.6f}")
                
                mort_2025_gm = self.gompertz_makeham(ages, A_2025, B_2025, C)
                
                print(f"  Gompertz-Makeham 2025预测死亡率范围: {mort_2025_gm.min():.6f} - {mort_2025_gm.max():.6f}")
                
                print(f"  关键年龄GM 2025预测:")
                for key_age in key_ages:
                    if key_age in ages:
                        idx = np.where(ages == key_age)[0][0]
                        pred_gm = mort_2025_gm[idx]
                        real_2021 = mort_2021[idx]
                        print(f"    {key_age}岁: GM 2025={pred_gm:.6f}, vs实际2021={real_2021:.6f}, 比值={pred_gm/real_2021:.3f}")
                
                # 组合两种方法的预测结果，使用更平滑的权重过渡
                weights_gm = np.zeros_like(ages, dtype=float)
                for i, age in enumerate(ages):
                    if age <= 25:
                        weights_gm[i] = 0.1  # 低年龄更依赖Lee-Carter
                    elif age <= 40:
                        weights_gm[i] = 0.1 + 0.3 * (age - 25) / 15  # 平滑过渡
                    elif age <= 65:
                        weights_gm[i] = 0.4 + 0.3 * (age - 40) / 25  # 继续平滑过渡
                    else:
                        weights_gm[i] = 0.7  # 高年龄更依赖Gompertz-Makeham
                
                weights_lc = 1 - weights_gm
                
                # 加权组合
                mort_2025_combined = weights_lc * mort_2025_lc + weights_gm * mort_2025_gm
                
                print(f"  组合模型2025预测死亡率范围: {mort_2025_combined.min():.6f} - {mort_2025_combined.max():.6f}")
                
                print(f"  关键年龄组合模型预测 (权重GM/LC):")
                for key_age in key_ages:
                    if key_age in ages:
                        idx = np.where(ages == key_age)[0][0]
                        pred_combined = mort_2025_combined[idx]
                        real_2021 = mort_2021[idx]
                        w_gm = weights_gm[idx]
                        w_lc = weights_lc[idx]
                        print(f"    {key_age}岁: 组合={pred_combined:.6f}, vs实际2021={real_2021:.6f}, 比值={pred_combined/real_2021:.3f}, 权重GM={w_gm:.1f}/LC={w_lc:.1f}")
            else:
                # 如果Gompertz-Makeham拟合失败，只使用Lee-Carter
                print(f"  警告: Gompertz-Makeham拟合失败，只使用Lee-Carter")
                mort_2025_combined = mort_2025_lc
                self.gompertz_params[gender] = None
            
            # 修匀处理前记录
            print(f"  修匀前死亡率范围: {mort_2025_combined.min():.6f} - {mort_2025_combined.max():.6f}")
            
            # 修匀处理
            mort_2025_smoothed = self.whittaker_henderson_smooth(mort_2025_combined, lambda_param=1000)
            
            print(f"  修匀后死亡率范围: {mort_2025_smoothed.min():.6f} - {mort_2025_smoothed.max():.6f}")
            
            # 检查修匀对关键年龄的影响
            print(f"  修匀对关键年龄的影响:")
            for key_age in key_ages:
                if key_age in ages:
                    idx = np.where(ages == key_age)[0][0]
                    before = mort_2025_combined[idx]
                    after = mort_2025_smoothed[idx]
                    real_2021 = mort_2021[idx]
                    print(f"    {key_age}岁: 修匀前={before:.6f}, 修匀后={after:.6f}, 变化={((after/before-1)*100):.1f}%, vs实际2021={real_2021:.6f}")
            
            # 确保单调性（对于30岁以上）
            monotonic_violations = 0
            for i in range(1, len(mort_2025_smoothed)):
                if ages[i] > 30 and mort_2025_smoothed[i] < mort_2025_smoothed[i-1]:
                    mort_2025_smoothed[i] = mort_2025_smoothed[i-1] * 1.01
                    monotonic_violations += 1
            
            if monotonic_violations > 0:
                print(f"  单调性修正: {monotonic_violations}个年龄点被调整")
            
            print(f"  最终预测死亡率范围: {mort_2025_smoothed.min():.6f} - {mort_2025_smoothed.max():.6f}")
            
            self.predictions_2025[gender] = {
                'ages': ages,
                'mortality_lc': mort_2025_lc,
                'mortality_combined': mort_2025_combined,
                'mortality_smoothed': mort_2025_smoothed,
                'kt_2025': kt_2025,
                'trend_slope': trend_slope
            }
            
        print("\n2025年死亡率预测完成！")
    
    def adjust_80plus_with_international_data(self, intl_data_path='国外数据'):
        """
        使用国际数据调整80岁以上的死亡率预测
        
        基本思路：
        1. 读取国际死亡率数据
        2. 寻找与我们的数据在80岁之前模式相似的国家
        3. 使用这些相似国家80岁以上的死亡率模式来调整我们的预测
        """
        print("\n使用国际数据调整80岁以上的死亡率...")
        
        # 国际数据目录
        death_rates_path = os.path.join(intl_data_path, 'death_rates', 'Mx_1x1')
        if not os.path.exists(death_rates_path):
            print(f"错误：找不到国际数据目录 {death_rates_path}")
            return False
        
        # 读取所有可用的国家数据
        country_files = [f for f in os.listdir(death_rates_path) if f.endswith('.txt')]
        print(f"找到{len(country_files)}个国家的死亡率数据")
        
        # 保存国际数据
        international_data = {}
        
        # 读取国际死亡率数据
        for gender in ['M', 'F']:
            international_data[gender] = {}
            gender_key = 'Male' if gender == 'M' else 'Female'
            
            # 读取每个国家的数据
            for country_file in country_files:
                country_code = country_file.split('.')[0]
                file_path = os.path.join(death_rates_path, country_file)
                
                try:
                    # 读取文件（跳过前两行）
                    with open(file_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()[2:]  # 跳过前两行
                    
                    # 提取列标题
                    header = lines[0].strip().split()
                    
                    # 确定性别列的索引
                    gender_idx = header.index(gender_key) if gender_key in header else None
                    
                    if gender_idx is None:
                        continue
                    
                    # 提取数据
                    country_data = {'ages': [], 'rates': [], 'years': []}
                    recent_year_data = {}  # 按年龄存储最新年份的数据
                    
                    for line in lines[1:]:
                        parts = line.strip().split()
                        if len(parts) >= 4:  # 确保有足够的列
                            try:
                                year = int(parts[0])
                                age = int(parts[1])
                                rate = float(parts[gender_idx])
                                
                                # 只保存0-110岁的数据
                                if 0 <= age <= 110 and rate > 0:
                                    country_data['ages'].append(age)
                                    country_data['rates'].append(rate)
                                    country_data['years'].append(year)
                                    
                                    # 更新最新年份的数据
                                    if age not in recent_year_data or year > recent_year_data[age]['year']:
                                        recent_year_data[age] = {'rate': rate, 'year': year}
                            except:
                                continue
                    
                    # 如果数据太少，跳过
                    if len(country_data['ages']) < 50:
                        continue
                    
                    # 提取所有年龄的最新数据
                    latest_ages = []
                    latest_rates = []
                    
                    for age in range(0, 111):
                        if age in recent_year_data:
                            latest_ages.append(age)
                            latest_rates.append(recent_year_data[age]['rate'])
                    
                    if len(latest_ages) > 30:  # 确保有足够的数据点
                        international_data[gender][country_code] = {
                            'ages': np.array(latest_ages),
                            'rates': np.array(latest_rates)
                        }
                        print(f"  导入{country_code} {gender_key}数据: {len(latest_ages)}个年龄点")
                except Exception as e:
                    print(f"  读取{country_file}时出错: {str(e)}")
            
            print(f"  成功导入{len(international_data[gender])}个国家的{gender_key}数据")
        
        # 对每个性别，寻找最相似的国家并调整80岁以上的死亡率
        for gender in ['M', 'F']:
            if gender not in self.predictions_2025:
                continue
                
            pred_ages = self.predictions_2025[gender]['ages']
            pred_mort = self.predictions_2025[gender]['mortality_smoothed']
            
            print(f"\n{gender}性80岁以上数据调整:")
            
            # 计算每个国家在80岁以前的相似度
            similarity_scores = {}
            
            for country, data in international_data[gender].items():
                country_ages = data['ages']
                country_rates = data['rates']
                
                # 计算40-80岁年龄段的相似度（使用对数尺度）
                err_sum = 0
                count = 0
                
                for age in range(40, 81):
                    if age in pred_ages and age in country_ages:
                        idx_pred = np.where(pred_ages == age)[0][0]
                        idx_country = np.where(country_ages == age)[0][0]
                        
                        pred_rate = pred_mort[idx_pred]
                        country_rate = country_rates[idx_country]
                        
                        if pred_rate > 0 and country_rate > 0:
                            # 计算对数空间中的差距
                            log_diff = np.abs(np.log(pred_rate) - np.log(country_rate))
                            err_sum += log_diff
                            count += 1
                
                if count > 0:
                    avg_err = err_sum / count
                    similarity_scores[country] = {
                        'score': np.exp(-avg_err),  # 转换为相似度分数（0-1之间）
                        'error': avg_err
                    }
            
            # 根据相似度排序
            sorted_countries = sorted(
                similarity_scores.items(),
                key=lambda x: x[1]['score'], 
                reverse=True
            )
            
            # 选择前5名最相似的国家
            top_countries = [c[0] for c in sorted_countries[:5]]
            print(f"  最相似的5个国家: {', '.join(top_countries)}")
            
            for c in sorted_countries[:5]:
                print(f"    {c[0]}: 相似度={c[1]['score']:.4f}, 误差={c[1]['error']:.4f}")
            
            # 使用选定的国家来调整80岁以上的死亡率
            if len(top_countries) > 0:
                # 提取80岁以上的数据
                ages_80plus = list(range(80, 111))  # 80-110岁
                avg_rates = np.zeros(len(ages_80plus))
                count = np.zeros(len(ages_80plus))
                
                # 计算加权平均
                for country in top_countries:
                    weight = similarity_scores[country]['score']
                    country_data = international_data[gender][country]
                    
                    for i, age in enumerate(ages_80plus):
                        if age in country_data['ages']:
                            idx = np.where(country_data['ages'] == age)[0][0]
                            rate = country_data['rates'][idx]
                            
                            if rate > 0:
                                avg_rates[i] += rate * weight
                                count[i] += weight
                
                # 计算平均率
                for i in range(len(ages_80plus)):
                    if count[i] > 0:
                        avg_rates[i] /= count[i]
                
                # 调整平均率，使其与我们的80岁死亡率连续
                idx_80 = np.where(pred_ages == 80)[0]
                if len(idx_80) > 0:
                    idx_80 = idx_80[0]
                    our_80 = pred_mort[idx_80]
                    intl_80 = avg_rates[0]
                    
                    # 计算调整系数
                    adjustment_factor = our_80 / intl_80 if intl_80 > 0 else 1.0
                    print(f"  调整系数: {adjustment_factor:.4f} (我们的80岁死亡率/国际80岁平均死亡率)")
                    
                    # 应用调整系数
                    avg_rates *= adjustment_factor
                    
                    # 针对70-80岁设置平滑过渡
                    for age in range(70, 80):
                        if age in pred_ages:
                            idx = np.where(pred_ages == age)[0][0]
                            # 保持不变，因为我们只调整80岁以上的数据
                    
                    # 应用调整后的80岁以上死亡率
                    for i, age in enumerate(ages_80plus):
                        if age in pred_ages:
                            idx = np.where(pred_ages == age)[0][0]
                            if avg_rates[i] > 0:
                                old_rate = pred_mort[idx]
                                new_rate = avg_rates[i]
                                print(f"    {age}岁: {old_rate:.6f} -> {new_rate:.6f} (变化率: {(new_rate/old_rate-1)*100:.1f}%)")
                                pred_mort[idx] = new_rate
                
                # 更新预测结果
                self.predictions_2025[gender]['mortality_adjusted'] = pred_mort.copy()
                
                # 比较调整前后的关键年龄
                key_ages = [80, 85, 90, 95, 100]
                print("\n  调整前后的关键年龄对比:")
                print("  年龄 | 原始预测 | 调整后 | 变化率")
                print("  --------------------------------")
                
                for age in key_ages:
                    if age in pred_ages:
                        idx = np.where(pred_ages == age)[0][0]
                        old_val = self.predictions_2025[gender]['mortality_smoothed'][idx]
                        new_val = pred_mort[idx]
                        change = (new_val / old_val - 1) * 100
                        print(f"  {age:3d} | {old_val:.6f} | {new_val:.6f} | {change:+.1f}%")
                
                # 再次进行修匀
                adjusted_mort_smoothed = self.whittaker_henderson_smooth(pred_mort, lambda_param=1000)
                self.predictions_2025[gender]['mortality_smoothed'] = adjusted_mort_smoothed
                
                # 确保单调性（对于30岁以上）
                monotonic_violations = 0
                for i in range(1, len(adjusted_mort_smoothed)):
                    if pred_ages[i] > 30 and adjusted_mort_smoothed[i] < adjusted_mort_smoothed[i-1]:
                        adjusted_mort_smoothed[i] = adjusted_mort_smoothed[i-1] * 1.01
                        monotonic_violations += 1
                
                if monotonic_violations > 0:
                    print(f"  单调性修正: {monotonic_violations}个年龄点被调整")
                
                print(f"  最终调整后死亡率范围: {adjusted_mort_smoothed.min():.6f} - {adjusted_mort_smoothed.max():.6f}")
            else:
                print("  没有找到足够相似的国家，保持原始预测")
        
        print("\n80岁以上死亡率调整完成！")
        return True
    
    def extrapolate_to_120(self):
        """外推至120岁"""
        print("正在外推至120岁...")
        
        for gender in ['M', 'F']:
            print(f"处理{gender}性外推...")
            
            current_ages = self.predictions_2025[gender]['ages']
            current_mortality = self.predictions_2025[gender]['mortality_smoothed']
            
            # 创建120岁的年龄序列
            extended_ages = np.arange(0, 121)
            extended_mortality = np.zeros(121)
            
            # 对于现有年龄范围，使用预测值
            for i, age in enumerate(extended_ages):
                if age in current_ages:
                    idx = np.where(current_ages == age)[0][0]
                    extended_mortality[i] = current_mortality[idx]
            
            # 对于90岁以上，使用Gompertz-Makeham外推
            if self.gompertz_params[gender] is not None:
                gm_params = self.gompertz_params[gender]['params']
                
                # 外推90-120岁
                for age in range(91, 121):
                    if age in extended_ages:
                        idx = age  # 因为extended_ages是0-120
                        # 使用Gompertz-Makeham模型外推
                        extended_mortality[idx] = self.gompertz_makeham(age, *gm_params)
                        
                        # 应用上限约束（死亡率不超过80%）
                        extended_mortality[idx] = min(extended_mortality[idx], 0.8)
            else:
                # 如果没有Gompertz-Makeham参数，使用指数外推
                last_valid_age = int(current_ages[-1])
                last_mortality = current_mortality[-1]
                
                # 估计增长率
                if len(current_mortality) >= 10:
                    growth_rate = np.mean(np.diff(np.log(current_mortality[-10:])))
                else:
                    growth_rate = 0.1  # 默认增长率
                
                for age in range(last_valid_age + 1, 121):
                    years_ahead = age - last_valid_age
                    extended_mortality[age] = last_mortality * np.exp(growth_rate * years_ahead)
                    extended_mortality[age] = min(extended_mortality[age], 0.8)
            
            # 对于低年龄段（0-现有最小年龄），使用插值
            min_age = int(current_ages[0])
            if min_age > 0:
                # 简单线性插值至0岁
                for age in range(0, min_age):
                    ratio = age / min_age
                    extended_mortality[age] = extended_mortality[min_age] * ratio
            
            # 最终修匀
            extended_mortality = self.whittaker_henderson_smooth(extended_mortality, lambda_param=500)
            
            # 确保单调性约束（30岁以上）
            for i in range(31, 121):
                if extended_mortality[i] < extended_mortality[i-1]:
                    extended_mortality[i] = extended_mortality[i-1] * 1.005
            
            # 确保非负性
            extended_mortality = np.maximum(extended_mortality, 1e-6)
            
            self.extrapolated_120[gender] = {
                'ages': extended_ages,
                'mortality': extended_mortality
            }
            
        print("120岁外推完成！")
    
    def generate_results_table(self):
        """生成结果表格"""
        results = []
        
        for gender in ['M', 'F']:
            ages = self.extrapolated_120[gender]['ages']
            mortality = self.extrapolated_120[gender]['mortality']
            
            for i, age in enumerate(ages):
                results.append({
                    '性别': gender,
                    '年龄': age,
                    '2025年预测死亡率': mortality[i]
                })
        
        return pd.DataFrame(results)
    
    def create_visualizations(self, save_path="Task 2"):
        """创建可视化图表"""
        print("正在生成可视化图表...")
        
        # 创建保存目录
        os.makedirs(save_path, exist_ok=True)
        
        # 1. 历史趋势分析图
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        for i, gender in enumerate(['M', 'F']):
            # 历史死亡率趋势
            matrix = self.mortality_matrix[gender]
            
            # 选择几个关键年龄显示趋势
            key_ages = [30, 50, 70, 90]
            for age in key_ages:
                if age in matrix.index:
                    values = matrix.loc[age].values
                    years = matrix.columns.values
                    axes[i, 0].plot(years, values, marker='o', label=f'{age}岁', linewidth=2)
            
            axes[i, 0].set_title(f'{gender}性历史死亡率趋势', fontsize=14)
            axes[i, 0].set_xlabel('年份')
            axes[i, 0].set_ylabel('死亡率')
            axes[i, 0].legend()
            axes[i, 0].grid(True, alpha=0.3)
            
            # Lee-Carter模型参数
            if gender in self.lee_carter_params:
                lc_params = self.lee_carter_params[gender]
                
                # b(x)参数图
                axes[i, 1].plot(lc_params['ages'], lc_params['bx'], 'b-', linewidth=2)
                axes[i, 1].set_title(f'{gender}性Lee-Carter模型b(x)参数', fontsize=14)
                axes[i, 1].set_xlabel('年龄')
                axes[i, 1].set_ylabel('b(x)')
                axes[i, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f'{save_path}/historical_analysis.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 2. 2025年预测结果图
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        for i, gender in enumerate(['M', 'F']):
            pred_data = self.predictions_2025[gender]
            
            axes[i].plot(pred_data['ages'], pred_data['mortality_lc'], 
                        'b--', label='Lee-Carter预测', linewidth=2, alpha=0.7)
            axes[i].plot(pred_data['ages'], pred_data['mortality_combined'], 
                        'g:', label='组合模型预测', linewidth=2, alpha=0.7)
            axes[i].plot(pred_data['ages'], pred_data['mortality_smoothed'], 
                        'r-', label='修匀后预测', linewidth=3)
            
            # 添加历史数据对比
            hist_2021 = self.mortality_matrix[gender][2021]
            axes[i].plot(hist_2021.index, hist_2021.values, 
                        'ko-', label='2021年实际', alpha=0.5, markersize=3)
            
            axes[i].set_title(f'{gender}性2025年死亡率预测', fontsize=14)
            axes[i].set_xlabel('年龄')
            axes[i].set_ylabel('死亡率')
            axes[i].set_yscale('log')
            axes[i].legend()
            axes[i].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f'{save_path}/prediction_2025.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. 120岁外推结果图
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        for i, gender in enumerate(['M', 'F']):
            ext_data = self.extrapolated_120[gender]
            
            axes[i].plot(ext_data['ages'], ext_data['mortality'], 
                        'r-', linewidth=3, label='外推至120岁')
            
            # 标记90岁分界线
            axes[i].axvline(x=90, color='blue', linestyle='--', alpha=0.7, label='原始数据边界')
            
            axes[i].set_title(f'{gender}性死亡率外推至120岁', fontsize=14)
            axes[i].set_xlabel('年龄')
            axes[i].set_ylabel('死亡率')
            axes[i].set_yscale('log')
            axes[i].legend()
            axes[i].grid(True, alpha=0.3)
            
            # 添加年龄段标注
            axes[i].text(45, ext_data['mortality'][45], '成年期', fontsize=10, alpha=0.7)
            axes[i].text(75, ext_data['mortality'][75], '老年期', fontsize=10, alpha=0.7)
            axes[i].text(105, ext_data['mortality'][105], '外推区间', fontsize=10, alpha=0.7)
        
        plt.tight_layout()
        plt.savefig(f'{save_path}/extrapolation_120.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 4. 模型比较图
        fig, axes = plt.subplots(2, 1, figsize=(12, 10))
        
        for i, gender in enumerate(['M', 'F']):
            # Gompertz-Makeham拟合效果
            if self.gompertz_params[gender] is not None:
                gm_data = self.gompertz_params[gender]
                fit_ages = gm_data['fit_ages']
                fit_rates = gm_data['fit_rates']
                predicted_rates = self.gompertz_makeham(fit_ages, *gm_data['params'])
                
                axes[i].scatter(fit_ages, fit_rates, alpha=0.6, label='实际数据', s=30)
                axes[i].plot(fit_ages, predicted_rates, 'r-', 
                           label=f'Gompertz-Makeham拟合 (R²={gm_data["r_squared"]:.3f})', linewidth=2)
                
                axes[i].set_title(f'{gender}性Gompertz-Makeham模型拟合效果', fontsize=14)
                axes[i].set_xlabel('年龄')
                axes[i].set_ylabel('死亡率')
                axes[i].set_yscale('log')
                axes[i].legend()
                axes[i].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(f'{save_path}/model_fitting.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print("可视化图表生成完成！")
    
    def run_complete_analysis(self):
        """运行完整分析流程"""
        print("开始完整的死亡率预测分析...")
        print("="*60)
        
        # 1. 数据加载和预处理
        self.load_and_prepare_data()
        
        # 2. 2025年预测
        self.predict_2025_mortality()
        
        # 3. 80岁以上死亡率调整
        self.adjust_80plus_with_international_data()
        
        # 4. 120岁外推
        self.extrapolate_to_120()
        
        # 5. 生成结果表格
        results_df = self.generate_results_table()
        
        # 6. 创建可视化
        self.create_visualizations()
        
        # 7. 保存结果
        results_df.to_csv('Task 2/mortality_predictions_2025.csv', index=False, encoding='utf-8-sig')
        
        print("="*60)
        print("分析完成！结果已保存到 Task 2 文件夹")
        
        return results_df


if __name__ == "__main__":
    # 使用示例
    predictor = MortalityPredictor("【选题1数据】某保险产品死亡率.xlsx")
    results = predictor.run_complete_analysis()
    
    # 显示部分结果
    print("\n预测结果示例:")
    print(results.head(20)) 