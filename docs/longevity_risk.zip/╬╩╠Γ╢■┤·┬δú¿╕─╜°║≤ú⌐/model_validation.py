"""
模型验证与合理性分析模块
用于评估死亡率预测模型的质量和结果的合理性
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

class ModelValidator:
    def __init__(self, predictor):
        """
        初始化模型验证器
        
        Parameters:
        predictor: MortalityPredictor实例
        """
        self.predictor = predictor
        self.validation_results = {}
        
    def cross_validation_analysis(self):
        """交叉验证分析"""
        print("进行交叉验证分析...")
        
        validation_results = {}
        
        for gender in ['M', 'F']:
            print(f"验证{gender}性模型...")
            
            matrix = self.predictor.mortality_matrix[gender]
            years = matrix.columns.values
            
            # 使用留一年法进行交叉验证
            errors_lc = []
            errors_gm = []
            
            for test_year in years[-3:]:  # 测试最后3年
                # 训练集：除test_year外的所有年份
                train_years = [y for y in years if y != test_year]
                train_matrix = matrix[train_years]
                
                # 拟合Lee-Carter模型
                log_mort = np.log(train_matrix.values)
                ax = np.mean(log_mort, axis=1)
                centered_matrix = log_mort - ax.reshape(-1, 1)
                U, s, Vt = np.linalg.svd(centered_matrix, full_matrices=False)
                bx = U[:, 0] / np.sum(U[:, 0])
                kt = s[0] * Vt[0, :]
                kt = kt - kt[0]
                
                # 预测test_year
                # 简单线性外推
                train_years_array = np.array(train_years)
                slope = np.polyfit(train_years_array, kt, 1)[0]
                kt_pred = kt[-1] + slope * (test_year - train_years[-1])
                
                # 计算预测死亡率
                log_mort_pred = ax + bx * kt_pred
                mort_pred_lc = np.exp(log_mort_pred)
                
                # 实际值
                mort_actual = matrix[test_year].values
                
                # 计算误差
                valid_mask = np.isfinite(mort_actual) & np.isfinite(mort_pred_lc)
                if np.sum(valid_mask) > 0:
                    mse_lc = mean_squared_error(mort_actual[valid_mask], mort_pred_lc[valid_mask])
                    errors_lc.append(mse_lc)
                
                # 对于Gompertz-Makeham，使用更简单的验证
                if len(train_matrix.columns) > 5:  # 确保有足够数据
                    recent_mort = train_matrix.iloc[:, -1].values
                    ages = train_matrix.index.values
                    
                    # 拟合Gompertz-Makeham
                    gm_result = self.predictor.fit_gompertz_makeham(ages, recent_mort)
                    if gm_result is not None:
                        mort_pred_gm = self.predictor.gompertz_makeham(ages, *gm_result['params'])
                        
                        if np.sum(valid_mask) > 0:
                            mse_gm = mean_squared_error(mort_actual[valid_mask], mort_pred_gm[valid_mask])
                            errors_gm.append(mse_gm)
            
            validation_results[gender] = {
                'lc_mse': np.mean(errors_lc) if errors_lc else np.nan,
                'gm_mse': np.mean(errors_gm) if errors_gm else np.nan,
                'lc_errors': errors_lc,
                'gm_errors': errors_gm
            }
            
        self.validation_results['cross_validation'] = validation_results
        print("交叉验证完成！")
        
    def residual_analysis(self):
        """残差分析"""
        print("进行残差分析...")
        
        residual_results = {}
        
        for gender in ['M', 'F']:
            if gender in self.predictor.lee_carter_params:
                lc_params = self.predictor.lee_carter_params[gender]
                matrix = self.predictor.mortality_matrix[gender]
                
                # 重构死亡率
                reconstructed_log = (lc_params['ax'].reshape(-1, 1) + 
                                   np.outer(lc_params['bx'], lc_params['kt']))
                reconstructed = np.exp(reconstructed_log)
                
                # 计算残差
                residuals = np.log(matrix.values) - reconstructed_log
                
                # 残差统计
                residual_stats = {
                    'mean': np.mean(residuals),
                    'std': np.std(residuals),
                    'skewness': stats.skew(residuals.flatten()),
                    'kurtosis': stats.kurtosis(residuals.flatten()),
                    'shapiro_p': stats.shapiro(residuals.flatten())[1] if residuals.size < 5000 else np.nan
                }
                
                residual_results[gender] = {
                    'residuals': residuals,
                    'stats': residual_stats,
                    'reconstructed': reconstructed
                }
        
        self.validation_results['residuals'] = residual_results
        print("残差分析完成！")
        
    def biological_plausibility_check(self):
        """生物学合理性检查"""
        print("进行生物学合理性检查...")
        
        plausibility_results = {}
        
        for gender in ['M', 'F']:
            ext_data = self.predictor.extrapolated_120[gender]
            ages = ext_data['ages']
            mortality = ext_data['mortality']
            
            checks = {}
            
            # 1. 单调性检查（30岁以上）
            age_30_idx = np.where(ages >= 30)[0]
            if len(age_30_idx) > 1:
                mortality_30plus = mortality[age_30_idx[0]:]
                ages_30plus = ages[age_30_idx[0]:]
                
                # 计算违反单调性的比例
                violations = 0
                for i in range(1, len(mortality_30plus)):
                    if mortality_30plus[i] < mortality_30plus[i-1]:
                        violations += 1
                
                monotonicity_ratio = 1 - violations / (len(mortality_30plus) - 1)
                checks['monotonicity_30plus'] = monotonicity_ratio
            
            # 2. 合理的死亡率范围检查
            checks['min_mortality'] = np.min(mortality)
            checks['max_mortality'] = np.max(mortality)
            checks['max_mortality_120'] = mortality[120] if len(mortality) > 120 else mortality[-1]
            
            # 3. 年龄增长模式检查
            # 计算死亡率加速度（二阶导数）
            if len(mortality) > 2:
                first_diff = np.diff(mortality)
                second_diff = np.diff(first_diff)
                checks['acceleration_mean'] = np.mean(second_diff)
                checks['acceleration_positive_ratio'] = np.sum(second_diff > 0) / len(second_diff)
            
            # 4. 与国际标准对比
            # 使用简化的国际参考值
            international_benchmarks = {
                'M': {'age_65': 0.015, 'age_85': 0.08, 'age_100': 0.3},
                'F': {'age_65': 0.010, 'age_85': 0.06, 'age_100': 0.25}
            }
            
            benchmark_checks = {}
            for age_label, benchmark_rate in international_benchmarks[gender].items():
                age_num = int(age_label.split('_')[1])
                if age_num < len(mortality):
                    predicted_rate = mortality[age_num]
                    ratio = predicted_rate / benchmark_rate
                    benchmark_checks[age_label] = {
                        'predicted': predicted_rate,
                        'benchmark': benchmark_rate,
                        'ratio': ratio
                    }
            
            checks['international_comparison'] = benchmark_checks
            
            plausibility_results[gender] = checks
        
        self.validation_results['plausibility'] = plausibility_results
        print("生物学合理性检查完成！")
        
    def model_performance_metrics(self):
        """模型性能指标"""
        print("计算模型性能指标...")
        
        performance_results = {}
        
        for gender in ['M', 'F']:
            if gender in self.predictor.lee_carter_params:
                lc_params = self.predictor.lee_carter_params[gender]
                matrix = self.predictor.mortality_matrix[gender]
                
                # Lee-Carter模型拟合优度
                reconstructed_log = (lc_params['ax'].reshape(-1, 1) + 
                                   np.outer(lc_params['bx'], lc_params['kt']))
                
                actual_log = np.log(matrix.values)
                
                # 计算R²
                ss_res = np.sum((actual_log - reconstructed_log) ** 2)
                ss_tot = np.sum((actual_log - np.mean(actual_log)) ** 2)
                r_squared_lc = 1 - (ss_res / ss_tot)
                
                # 计算其他指标
                mse_lc = mean_squared_error(actual_log.flatten(), reconstructed_log.flatten())
                mae_lc = mean_absolute_error(actual_log.flatten(), reconstructed_log.flatten())
                
                performance_results[gender] = {
                    'lee_carter': {
                        'r_squared': r_squared_lc,
                        'mse': mse_lc,
                        'mae': mae_lc,
                        'explained_variance': lc_params['kt'].var() / actual_log.var()
                    }
                }
                
                # Gompertz-Makeham性能
                if self.predictor.gompertz_params[gender] is not None:
                    gm_data = self.predictor.gompertz_params[gender]
                    performance_results[gender]['gompertz_makeham'] = {
                        'r_squared': gm_data['r_squared'],
                        'parameters': gm_data['params']
                    }
        
        self.validation_results['performance'] = performance_results
        print("模型性能指标计算完成！")
        
    def create_validation_visualizations(self, save_path="Task 2"):
        """创建验证可视化图表"""
        print("生成验证可视化图表...")
        
        # 1. 残差分析图
        if 'residuals' in self.validation_results:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            
            for i, gender in enumerate(['M', 'F']):
                if gender in self.validation_results['residuals']:
                    residuals = self.validation_results['residuals'][gender]['residuals']
                    
                    # 残差热力图
                    im = axes[i, 0].imshow(residuals, cmap='RdBu_r', aspect='auto')
                    axes[i, 0].set_title(f'{gender}性Lee-Carter模型残差热力图')
                    axes[i, 0].set_xlabel('年份')
                    axes[i, 0].set_ylabel('年龄')
                    plt.colorbar(im, ax=axes[i, 0])
                    
                    # 残差分布直方图
                    axes[i, 1].hist(residuals.flatten(), bins=50, alpha=0.7, edgecolor='black')
                    axes[i, 1].set_title(f'{gender}性残差分布')
                    axes[i, 1].set_xlabel('残差值')
                    axes[i, 1].set_ylabel('频数')
                    axes[i, 1].grid(True, alpha=0.3)
                    
                    # 添加正态分布参考线
                    x = np.linspace(residuals.min(), residuals.max(), 100)
                    y = stats.norm.pdf(x, np.mean(residuals), np.std(residuals))
                    y = y * len(residuals.flatten()) * (residuals.max() - residuals.min()) / 50
                    axes[i, 1].plot(x, y, 'r-', label='正态分布', linewidth=2)
                    axes[i, 1].legend()
            
            plt.tight_layout()
            plt.savefig(f'{save_path}/residual_analysis.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # 2. 生物学合理性检查图
        if 'plausibility' in self.validation_results:
            fig, axes = plt.subplots(1, 2, figsize=(15, 6))
            
            for i, gender in enumerate(['M', 'F']):
                if gender in self.validation_results['plausibility']:
                    # 国际对比图
                    int_comp = self.validation_results['plausibility'][gender]['international_comparison']
                    
                    ages = []
                    predicted = []
                    benchmark = []
                    
                    for age_label, data in int_comp.items():
                        age_num = int(age_label.split('_')[1])
                        ages.append(age_num)
                        predicted.append(data['predicted'])
                        benchmark.append(data['benchmark'])
                    
                    if ages:
                        x = np.arange(len(ages))
                        width = 0.35
                        
                        axes[i].bar(x - width/2, predicted, width, label='预测值', alpha=0.8)
                        axes[i].bar(x + width/2, benchmark, width, label='国际参考', alpha=0.8)
                        
                        axes[i].set_xlabel('年龄')
                        axes[i].set_ylabel('死亡率')
                        axes[i].set_title(f'{gender}性预测结果与国际参考对比')
                        axes[i].set_xticks(x)
                        axes[i].set_xticklabels([f'{age}岁' for age in ages])
                        axes[i].legend()
                        axes[i].grid(True, alpha=0.3)
                        axes[i].set_yscale('log')
            
            plt.tight_layout()
            plt.savefig(f'{save_path}/plausibility_check.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # 3. 模型性能对比图
        if 'performance' in self.validation_results:
            fig, axes = plt.subplots(1, 2, figsize=(12, 5))
            
            genders = []
            r2_lc = []
            r2_gm = []
            
            for gender in ['M', 'F']:
                if gender in self.validation_results['performance']:
                    perf = self.validation_results['performance'][gender]
                    genders.append(gender)
                    r2_lc.append(perf['lee_carter']['r_squared'])
                    if 'gompertz_makeham' in perf:
                        r2_gm.append(perf['gompertz_makeham']['r_squared'])
                    else:
                        r2_gm.append(0)
            
            x = np.arange(len(genders))
            width = 0.35
            
            axes[0].bar(x - width/2, r2_lc, width, label='Lee-Carter R²', alpha=0.8)
            axes[0].bar(x + width/2, r2_gm, width, label='Gompertz-Makeham R²', alpha=0.8)
            axes[0].set_xlabel('性别')
            axes[0].set_ylabel('R² 值')
            axes[0].set_title('模型拟合优度对比')
            axes[0].set_xticks(x)
            axes[0].set_xticklabels(genders)
            axes[0].legend()
            axes[0].grid(True, alpha=0.3)
            
            # MSE对比
            mse_lc = []
            for gender in genders:
                if gender in self.validation_results['performance']:
                    mse_lc.append(self.validation_results['performance'][gender]['lee_carter']['mse'])
            
            axes[1].bar(genders, mse_lc, alpha=0.8, color='orange')
            axes[1].set_xlabel('性别')
            axes[1].set_ylabel('MSE')
            axes[1].set_title('Lee-Carter模型预测误差')
            axes[1].grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(f'{save_path}/model_performance.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        print("验证可视化图表生成完成！")
        
    def generate_validation_report(self):
        """生成验证报告"""
        report = []
        report.append("="*60)
        report.append("死亡率预测模型验证报告")
        report.append("="*60)
        
        # 1. 模型性能总结
        report.append("\n1. 模型性能总结")
        report.append("-" * 30)
        
        if 'performance' in self.validation_results:
            for gender in ['M', 'F']:
                if gender in self.validation_results['performance']:
                    perf = self.validation_results['performance'][gender]
                    report.append(f"\n{gender}性:")
                    report.append(f"  Lee-Carter模型 R²: {perf['lee_carter']['r_squared']:.4f}")
                    report.append(f"  Lee-Carter模型 MSE: {perf['lee_carter']['mse']:.6f}")
                    
                    if 'gompertz_makeham' in perf:
                        report.append(f"  Gompertz-Makeham模型 R²: {perf['gompertz_makeham']['r_squared']:.4f}")
        
        # 2. 生物学合理性评估
        report.append("\n\n2. 生物学合理性评估")
        report.append("-" * 30)
        
        if 'plausibility' in self.validation_results:
            for gender in ['M', 'F']:
                if gender in self.validation_results['plausibility']:
                    plaus = self.validation_results['plausibility'][gender]
                    report.append(f"\n{gender}性:")
                    
                    if 'monotonicity_30plus' in plaus:
                        mono_ratio = plaus['monotonicity_30plus']
                        report.append(f"  30岁以上单调性: {mono_ratio:.2%} (良好阈值>95%)")
                        
                    report.append(f"  最小死亡率: {plaus['min_mortality']:.6f}")
                    report.append(f"  最大死亡率: {plaus['max_mortality']:.6f}")
                    
                    if 'max_mortality_120' in plaus:
                        report.append(f"  120岁死亡率: {plaus['max_mortality_120']:.6f}")
                    
                    # 国际对比
                    if 'international_comparison' in plaus:
                        report.append("  国际对比:")
                        for age_label, data in plaus['international_comparison'].items():
                            age = age_label.split('_')[1]
                            ratio = data['ratio']
                            status = "合理" if 0.5 <= ratio <= 2.0 else "需关注"
                            report.append(f"    {age}岁: 预测/参考 = {ratio:.2f} ({status})")
        
        # 3. 残差分析
        report.append("\n\n3. 残差分析")
        report.append("-" * 30)
        
        if 'residuals' in self.validation_results:
            for gender in ['M', 'F']:
                if gender in self.validation_results['residuals']:
                    res_stats = self.validation_results['residuals'][gender]['stats']
                    report.append(f"\n{gender}性残差统计:")
                    report.append(f"  均值: {res_stats['mean']:.6f} (理想值≈0)")
                    report.append(f"  标准差: {res_stats['std']:.6f}")
                    report.append(f"  偏度: {res_stats['skewness']:.4f} (理想值≈0)")
                    report.append(f"  峰度: {res_stats['kurtosis']:.4f} (理想值≈0)")
                    
                    if not np.isnan(res_stats['shapiro_p']):
                        normality = "正态" if res_stats['shapiro_p'] > 0.05 else "非正态"
                        report.append(f"  正态性检验 p值: {res_stats['shapiro_p']:.4f} ({normality})")
        
        # 4. 交叉验证结果
        if 'cross_validation' in self.validation_results:
            report.append("\n\n4. 交叉验证结果")
            report.append("-" * 30)
            
            for gender in ['M', 'F']:
                if gender in self.validation_results['cross_validation']:
                    cv_results = self.validation_results['cross_validation'][gender]
                    report.append(f"\n{gender}性:")
                    
                    if not np.isnan(cv_results['lc_mse']):
                        report.append(f"  Lee-Carter平均MSE: {cv_results['lc_mse']:.6f}")
                    
                    if not np.isnan(cv_results['gm_mse']):
                        report.append(f"  Gompertz-Makeham平均MSE: {cv_results['gm_mse']:.6f}")
        
        # 5. 总体评估
        report.append("\n\n5. 总体评估与建议")
        report.append("-" * 30)
        report.append("\n模型质量评级:")
        
        # 简单的评级逻辑
        overall_quality = "良好"
        
        if 'performance' in self.validation_results:
            avg_r2 = np.mean([self.validation_results['performance'][g]['lee_carter']['r_squared'] 
                             for g in ['M', 'F'] if g in self.validation_results['performance']])
            if avg_r2 < 0.8:
                overall_quality = "需改进"
            elif avg_r2 > 0.95:
                overall_quality = "优秀"
        
        report.append(f"  整体质量: {overall_quality}")
        
        report.append("\n建议:")
        report.append("  1. 定期更新模型参数以反映最新趋势")
        report.append("  2. 监控预测结果与实际观测的偏差")
        report.append("  3. 考虑外部因素（医疗技术进步、政策变化等）的影响")
        report.append("  4. 建立预测区间以量化不确定性")
        
        return "\n".join(report)
    
    def run_full_validation(self):
        """运行完整验证流程"""
        print("开始完整的模型验证...")
        print("="*50)
        
        # 执行各项验证
        self.cross_validation_analysis()
        self.residual_analysis()
        self.biological_plausibility_check()
        self.model_performance_metrics()
        
        # 生成可视化
        self.create_validation_visualizations()
        
        # 生成报告
        report = self.generate_validation_report()
        
        # 保存报告
        with open('Task 2/validation_report.txt', 'w', encoding='utf-8') as f:
            f.write(report)
        
        print("="*50)
        print("模型验证完成！报告已保存到 Task 2/validation_report.txt")
        
        return report


if __name__ == "__main__":
    # 需要先运行mortality_predictor.py
    from mortality_predictor import MortalityPredictor
    
    predictor = MortalityPredictor("【选题1数据】某保险产品死亡率.xlsx")
    predictor.run_complete_analysis()
    
    validator = ModelValidator(predictor)
    validation_report = validator.run_full_validation()
    
    print(validation_report) 