"""
Long-Term Mortality Trend Forecast (2025-2125)
Core module implementing the forecasting methodology described in the report
"""

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from scipy.interpolate import splrep, splev
import matplotlib.pyplot as plt
import os
import sys

# Add parent directory to path to import Task 2 modules
sys.path.append('../../问题2报告/改进后')
try:
    from mortality_predictor import MortalityPredictor
except ImportError:
    print("Warning: Could not import MortalityPredictor from Task 2")


class LongTermMortalityModel:
    """
    Long-term mortality trend projection model (2025-2125)
    
    This model extends the short-term projections from Task 2 to create
    a 100-year forecast with gradually slowing improvement rates.
    """
    
    def __init__(self, data_path=None, task2_predictor=None):
        """
        Initialize the long-term mortality model
        
        Parameters:
        -----------
        data_path : str
            Path to the mortality data Excel file
        task2_predictor : MortalityPredictor
            Pre-initialized predictor from Task 2 (optional)
        """
        self.data_path = data_path
        self.predictor = task2_predictor
        self.projections = {}
        self.life_expectancy = {}
        
        # Key model parameters
        self.projection_start_year = 2025
        self.projection_end_year = 2125
        self.projection_years = list(range(self.projection_start_year, 
                                          self.projection_end_year + 1, 5))
        
        # Model parameters for the long-term improvement curves
        self.improvement_params = {
            'M': {
                'initial_rate': 0.015,  # Initial annual mortality improvement rate
                'asymptotic_rate': 0.003,  # Long-term "floor" improvement rate
                'half_life_years': 30,  # Years until improvement rate halves
            },
            'F': {
                'initial_rate': 0.012,  # Women start with slightly lower improvement rate
                'asymptotic_rate': 0.0025,  # But maintain a steady floor
                'half_life_years': 35,  # Women's improvement declines more slowly
            }
        }
        
        # Initialize projections dictionary structure
        self._initialize_projections()
    
    def _initialize_projections(self):
        """Initialize data structures for projections"""
        for gender in ['M', 'F']:
            self.projections[gender] = {
                'mortality_rates': {},  # Year -> age -> rate mapping
                'improvement_rates': {},  # Year -> age -> improvement rate
                'kt_values': {},  # Year -> kt value for Lee-Carter
            }
            
            self.life_expectancy[gender] = {
                'at_birth': {},  # Year -> e(0)
                'at_65': {},     # Year -> e(65)
            }
    
    def initialize_from_task2(self):
        """Initialize the model using Task 2's short-term projection"""
        if self.predictor is None:
            if self.data_path is None:
                raise ValueError("Either data_path or task2_predictor must be provided")
            
            print("Initializing short-term model from Task 2...")
            self.predictor = MortalityPredictor(self.data_path)
            self.predictor.run_complete_analysis()
        
        print("Extracting 2025 projections as baseline...")
        for gender in ['M', 'F']:
            if gender in self.predictor.extrapolated_120:
                # Get the full age range (0-120) mortality rates for 2025
                baseline_ages = np.arange(0, 121)
                baseline_rates = self.predictor.extrapolated_120[gender]['mortality']
                
                # Fix any rates that are too high (>0.9) in the base data
                for i, rate in enumerate(baseline_rates):
                    if rate > 0.9:
                        # Apply sigmoid transformation to keep rates below 1
                        baseline_rates[i] = 0.9 + 0.099 * (1 / (1 + np.exp(-(rate - 0.9) * 10)))
                
                # Store as the starting point for long-term projection
                self.projections[gender]['mortality_rates'][self.projection_start_year] = {
                    age: rate for age, rate in zip(baseline_ages, baseline_rates)
                }
    
    def improvement_decay_function(self, time, gender):
        """
        Model the decay of mortality improvement rates over time
        
        Parameters:
        -----------
        time : int or array
            Years from projection start (0 = 2025)
        gender : str
            'M' or 'F'
            
        Returns:
        --------
        float or array
            Mortality improvement rate at the given time
        """
        params = self.improvement_params[gender]
        initial = params['initial_rate']
        asymptotic = params['asymptotic_rate']
        half_life = params['half_life_years']
        
        # Exponential decay with floor
        decay_factor = np.exp(-np.log(2) * time / half_life)
        return asymptotic + (initial - asymptotic) * decay_factor
    
    def age_specific_improvement_pattern(self, age, gender, year_offset):
        """
        Create age-specific mortality improvement patterns
        
        Parameters:
        -----------
        age : int
            Age (0-120)
        gender : str
            'M' or 'F'
        year_offset : int
            Years from projection start (0 = 2025)
            
        Returns:
        --------
        float
            Age-specific mortality improvement factor
        """
        # Base improvement rate from the decay function
        base_rate = self.improvement_decay_function(year_offset, gender)
        
        # Age-specific modifiers
        if age < 10:
            # Child mortality improvements will continue strongly
            mod = 1.2
        elif age < 40:
            # Young adult improvements moderate
            mod = 0.8
        elif age < 65:
            # Middle age improvements average
            mod = 1.0
        elif age < 85:
            # Senior improvements above average initially
            mod = 1.1 * max(0.5, (1 - year_offset/80))  # Declining effect over time
        else:
            # Very elderly improvements below average and declining over time
            mod = 0.7 * max(0.3, (1 - year_offset/60))
        
        return base_rate * mod
    
    def _apply_gompertz_correction(self, age, rate):
        """
        Apply Gompertz correction to ensure mortality rates behave properly at high ages
        
        Parameters:
        -----------
        age : int
            The age
        rate : float
            The mortality rate
            
        Returns:
        --------
        float
            The corrected mortality rate
        """
        # For ages below 80, no correction needed
        if age < 80:
            return rate
            
        # For ages 80+, ensure rates follow reasonable Gompertz pattern
        # without exceeding theoretical maximum
        if rate > 0.6:
            # Use sigmoid function to asymptotically approach 1
            # as age increases and mortality gets higher
            sigmoid_factor = 1 / (1 + np.exp(-(rate - 0.85) * 15))
            return 0.6 + 0.399 * sigmoid_factor
            
        return rate
    
    def project_forward(self):
        """Project mortality rates forward for 100 years"""
        print(f"Projecting mortality rates from {self.projection_start_year} to {self.projection_end_year}...")
        
        for gender in ['M', 'F']:
            print(f"\nGenerating projections for gender: {gender}")
            
            # Get baseline mortality rates from 2025
            baseline_year = self.projection_start_year
            if baseline_year not in self.projections[gender]['mortality_rates']:
                raise ValueError(f"No baseline mortality for {gender} in {baseline_year}. "
                               "Run initialize_from_task2() first.")
                
            baseline_mortality = self.projections[gender]['mortality_rates'][baseline_year]
            ages = sorted(baseline_mortality.keys())
            
            # Project for each 5-year interval
            for i, year in enumerate(self.projection_years[1:], 1):
                self.projections[gender]['mortality_rates'][year] = {}
                self.projections[gender]['improvement_rates'][year] = {}
                
                year_offset = year - self.projection_start_year
                base_improvement = self.improvement_decay_function(year_offset, gender)
                print(f"  Year {year}: Base improvement rate = {base_improvement:.4f}")
                
                # Apply improvements by age
                for age in ages:
                    # Previous timepoint's mortality rate (may be 5 years ago)
                    prev_year = self.projection_years[i-1]
                    prev_rate = self.projections[gender]['mortality_rates'][prev_year][age]
                    
                    # Calculate age-specific improvement over 5 years
                    age_improvement = self.age_specific_improvement_pattern(age, gender, year_offset)
                    five_year_factor = (1 - age_improvement) ** 5  # Compound for 5 years
                    
                    # Apply improvement (reduction)
                    new_rate = prev_rate * five_year_factor
                    
                    # Ensure sensible lower bounds
                    if age < 5:
                        new_rate = max(new_rate, 0.0001)
                    else:
                        min_rate = 0.0001 * (1.05 ** (age - 5))
                        new_rate = max(new_rate, min_rate)
                    
                    # Apply Gompertz correction for high ages
                    new_rate = self._apply_gompertz_correction(age, new_rate)
                    
                    # Store results
                    self.projections[gender]['mortality_rates'][year][age] = new_rate
                    self.projections[gender]['improvement_rates'][year][age] = 1 - five_year_factor
                
            # Calculate life expectancy
            self.calculate_life_expectancy(gender)
    
    def calculate_life_expectancy(self, gender):
        """Calculate period life expectancy for each projection year"""
        print(f"Calculating life expectancy for {gender}...")
        
        for year in self.projection_years:
            mortality = self.projections[gender]['mortality_rates'][year]
            ages = sorted(mortality.keys())
            rates = [mortality[age] for age in ages]
            
            # Create life table
            lx = [100000]  # Radix of 100,000 lives
            for q in rates:
                lx.append(lx[-1] * (1 - min(q, 1.0)))  # Add survivors to next age
            
            # Calculate expectation of life
            T = sum(lx)  # Total person-years lived by the cohort
            ex = [sum(lx[i:]) / lx[i] if lx[i] > 0 else 0 for i in range(len(lx)-1)]
            
            # Store results
            self.life_expectancy[gender]['at_birth'][year] = ex[0]
            if 65 in ages:
                idx_65 = ages.index(65)
                self.life_expectancy[gender]['at_65'][year] = ex[idx_65]
        
        # Print summary
        start_year = self.projection_years[0]
        end_year = self.projection_years[-1]
        print(f"  Life expectancy at birth in {start_year}: {self.life_expectancy[gender]['at_birth'][start_year]:.2f} years")
        print(f"  Life expectancy at birth in {end_year}: {self.life_expectancy[gender]['at_birth'][end_year]:.2f} years")
        print(f"  Gain in e(0) over projection period: {self.life_expectancy[gender]['at_birth'][end_year] - self.life_expectancy[gender]['at_birth'][start_year]:.2f} years")
    
    def run_projection(self):
        """Run the full projection process"""
        self.initialize_from_task2()
        self.project_forward()
        return self.projections, self.life_expectancy 