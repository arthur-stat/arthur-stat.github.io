"""
Long-Term Mortality Trend Forecast (2025-2125)
Main execution script to run the long-term mortality projections
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# Add parent directory to path
sys.path.append('../../问题2报告/改进后')

# Import local modules
from long_term_mortality_model import LongTermMortalityModel
from visualization import MortalityVisualizer

# Configure paths
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(CURRENT_DIR, '..', '..', '..', '【选题1数据】某保险产品死亡率.xlsx')
OUTPUT_DIR = CURRENT_DIR

def format_mortality_table(projections, years=[2025, 2075, 2125], ages=[0, 20, 40, 60, 70, 80]):
    """
    Format mortality data into a presentable table
    
    Parameters:
    -----------
    projections : dict
        The projection results from the model
    years : list
        Years to include in the table
    ages : list
        Ages to include in the table
        
    Returns:
    --------
    pandas.DataFrame
        Formatted table of mortality rates
    """
    data = []
    
    for age in ages:
        row = {'Age': age}
        
        for gender in ['M', 'F']:
            gender_label = 'Male' if gender == 'M' else 'Female'
            
            for year in years:
                if year in projections[gender]['mortality_rates']:
                    if age in projections[gender]['mortality_rates'][year]:
                        rate = projections[gender]['mortality_rates'][year][age]
                        row[f'{gender_label} {year}'] = rate
        
        data.append(row)
    
    # Create DataFrame and format
    df = pd.DataFrame(data)
    
    # Format mortality rates as percentages
    for col in df.columns:
        if col != 'Age':
            df[col] = df[col].map('{:.6f}'.format)
    
    return df

def format_life_expectancy_table(life_expectancy, years=None):
    """
    Format life expectancy data into a presentable table
    
    Parameters:
    -----------
    life_expectancy : dict
        The life expectancy results from the model
    years : list
        Years to include in the table (default: all available years)
        
    Returns:
    --------
    pandas.DataFrame
        Formatted table of life expectancy values
    """
    if years is None:
        years = sorted(life_expectancy['M']['at_birth'].keys())
        
    # Filter to include only some years if too many
    if len(years) > 10:
        years = [years[0]] + [y for y in years if y % 25 == 0] + [years[-1]]
        
    data = []
    
    for year in years:
        row = {'Year': year}
        
        for gender in ['M', 'F']:
            gender_label = 'Male' if gender == 'M' else 'Female'
            
            if year in life_expectancy[gender]['at_birth']:
                row[f'{gender_label} e(0)'] = life_expectancy[gender]['at_birth'][year]
                
            if 'at_65' in life_expectancy[gender] and year in life_expectancy[gender]['at_65']:
                row[f'{gender_label} e(65)'] = life_expectancy[gender]['at_65'][year]
        
        # Calculate gender gap
        if 'Male e(0)' in row and 'Female e(0)' in row:
            row['Gender Gap'] = row['Female e(0)'] - row['Male e(0)']
            
        data.append(row)
    
    # Create DataFrame and format
    df = pd.DataFrame(data)
    
    # Format life expectancy values with 2 decimal places
    for col in df.columns:
        if col != 'Year':
            df[col] = df[col].map('{:.2f}'.format)
    
    return df

def save_projection_to_csv(projections, life_expectancy, output_dir):
    """
    Save projection results to CSV files
    
    Parameters:
    -----------
    projections : dict
        The projection results from the model
    life_expectancy : dict
        The life expectancy results from the model
    output_dir : str
        Directory to save the files
    
    Returns:
    --------
    list
        Paths to the saved files
    """
    os.makedirs(output_dir, exist_ok=True)
    saved_files = []
    
    # Save mortality rates table
    mortality_table = format_mortality_table(projections)
    mortality_path = os.path.join(output_dir, 'mortality_projection_table.csv')
    mortality_table.to_csv(mortality_path, index=False)
    saved_files.append(mortality_path)
    
    # Save life expectancy table
    life_exp_table = format_life_expectancy_table(life_expectancy)
    life_exp_path = os.path.join(output_dir, 'life_expectancy_projection.csv')
    life_exp_table.to_csv(life_exp_path, index=False)
    saved_files.append(life_exp_path)
    
    # Save detailed projections by gender
    for gender in ['M', 'F']:
        gender_label = 'male' if gender == 'M' else 'female'
        
        # Extract all mortality rates by year and age
        data = []
        
        for year in sorted(projections[gender]['mortality_rates'].keys()):
            mortality = projections[gender]['mortality_rates'][year]
            
            for age in sorted(mortality.keys()):
                data.append({
                    'Year': year,
                    'Age': age,
                    'Mortality_Rate': mortality[age]
                })
        
        # Create and save DataFrame
        df = pd.DataFrame(data)
        detailed_path = os.path.join(output_dir, f'detailed_{gender_label}_projection.csv')
        df.to_csv(detailed_path, index=False)
        saved_files.append(detailed_path)
    
    print(f"Saved {len(saved_files)} projection files:")
    for file in saved_files:
        print(f"  - {file}")
    
    return saved_files

def generate_summary_report(model, output_dir):
    """
    Generate a summary report of the long-term projection
    
    Parameters:
    -----------
    model : LongTermMortalityModel
        The model containing projections
    output_dir : str
        Directory to save the report
        
    Returns:
    --------
    str
        Path to the saved report
    """
    report = []
    report.append("="*70)
    report.append("LONG-TERM MORTALITY TREND FORECAST (2025-2125)")
    report.append("="*70)
    report.append("")
    
    # 1. Overview
    report.append("1. OVERVIEW")
    report.append("-"*50)
    report.append("This report presents a century-long mortality projection for the")
    report.append("insured population, based on the 2010-2021 experience data and")
    report.append("extending the short-term model (Lee-Carter + Gompertz-Makeham)")
    report.append("through 2125.")
    report.append("")
    
    # 2. Methodology
    report.append("2. METHODOLOGY")
    report.append("-"*50)
    report.append("The projection methodology follows these key principles:")
    report.append("  - Initial mortality patterns from Task 2's 2025 projection")
    report.append("  - Exponential decay of improvement rates over time")
    report.append("  - Age-specific improvement patterns with higher rates for younger ages")
    report.append("  - Modified Gompertz-Logistic pattern for elderly ages")
    report.append("  - Focus on ages 0-100 where data quality is most reliable")
    report.append("  - Persistent gender gap throughout the projection period")
    report.append("")
    
    # 3. Key Parameters
    report.append("3. KEY PARAMETERS")
    report.append("-"*50)
    report.append("Long-term improvement parameters:")
    
    for gender in ['M', 'F']:
        gender_label = 'Male' if gender == 'M' else 'Female'
        params = model.improvement_params[gender]
        
        report.append(f"  {gender_label}:")
        report.append(f"    - Initial annual improvement rate: {params['initial_rate']*100:.2f}%")
        report.append(f"    - Long-term asymptotic rate: {params['asymptotic_rate']*100:.2f}%")
        report.append(f"    - Half-life of improvement decay: {params['half_life_years']} years")
    
    report.append("")
    
    # 4. Key Results
    report.append("4. KEY RESULTS")
    report.append("-"*50)
    
    # Life expectancy at birth in 2025 and 2125
    start_year = model.projection_years[0]
    end_year = model.projection_years[-1]
    
    report.append(f"Life expectancy at birth:")
    for gender in ['M', 'F']:
        gender_label = 'Male' if gender == 'M' else 'Female'
        e0_start = model.life_expectancy[gender]['at_birth'][start_year]
        e0_end = model.life_expectancy[gender]['at_birth'][end_year]
        gain = e0_end - e0_start
        
        report.append(f"  {gender_label}:")
        report.append(f"    - {start_year}: {e0_start:.2f} years")
        report.append(f"    - {end_year}: {e0_end:.2f} years")
        report.append(f"    - Century gain: +{gain:.2f} years")
    
    report.append("")
    report.append("Gender gap in life expectancy at birth:")
    gap_start = model.life_expectancy['F']['at_birth'][start_year] - model.life_expectancy['M']['at_birth'][start_year]
    gap_end = model.life_expectancy['F']['at_birth'][end_year] - model.life_expectancy['M']['at_birth'][end_year]
    report.append(f"  - {start_year}: {gap_start:.2f} years")
    report.append(f"  - {end_year}: {gap_end:.2f} years")
    
    report.append("")
    report.append("Mortality rates at key ages (2125):")
    key_ages = [0, 20, 40, 60, 70, 80]
    
    for gender in ['M', 'F']:
        gender_label = 'Male' if gender == 'M' else 'Female'
        report.append(f"  {gender_label}:")
        
        mortality_2125 = model.projections[gender]['mortality_rates'][end_year]
        for age in key_ages:
            rate = mortality_2125[age]
            report.append(f"    - Age {age}: {rate:.6f}")
    
    report.append("")
    
    # 5. Conclusion
    report.append("5. CONCLUSION")
    report.append("-"*50)
    report.append("The century-long projection demonstrates steadily improving")
    report.append("mortality rates for both genders, with females maintaining")
    report.append("their survival advantage. Improvement rates gradually slow")
    report.append("over time, reflecting biological constraints and diminishing")
    report.append("returns from medical advances.")
    report.append("")
    report.append("The results show a plausible path for mortality development,")
    report.append("with no abrupt changes. The mortality pattern follows a")
    report.append("modified Gompertz-Logistic model that ensures rates remain")
    report.append("biologically plausible while preserving the exponential")
    report.append("age-pattern relationship.")
    report.append("")
    report.append("Note: The analysis focuses on ages 0-100 where data quality")
    report.append("is most reliable. Projections beyond age 100 should be")
    report.append("interpreted with appropriate caution due to data sparsity.")
    report.append("")
    
    # 6. Generated Files
    report.append("6. GENERATED FILES")
    report.append("-"*50)
    report.append("Data tables:")
    report.append("  - mortality_projection_table.csv")
    report.append("  - life_expectancy_projection.csv")
    report.append("  - detailed_male_projection.csv")
    report.append("  - detailed_female_projection.csv")
    report.append("")
    report.append("Visualizations:")
    report.append("  - life_expectancy_trend.png")
    report.append("  - mortality_curves.png")
    report.append("  - improvement_rates.png")
    report.append("  - age_improvements_2075.png")
    report.append("  - advanced_age_mortality.png")
    report.append("  - mortality_surface_M.png")
    report.append("  - mortality_surface_F.png")
    report.append("")
    
    # Save the report
    report_path = os.path.join(output_dir, 'long_term_projection_report.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(report))
    
    print(f"Generated summary report: {report_path}")
    
    return report_path

def main():
    print("="*70)
    print("LONG-TERM MORTALITY TREND FORECAST (2025-2125)")
    print("="*70)
    
    # Record start time
    start_time = datetime.now()
    print(f"Started at: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Check if the data file exists
    if not os.path.exists(DATA_DIR):
        print(f"Error: Data file not found at {DATA_DIR}")
        print("Please check the path and try again.")
        return
    
    try:
        # Initialize the model
        print("\nInitializing model...")
        model = LongTermMortalityModel(data_path=DATA_DIR)
        
        # Run the projection
        print("\nRunning 100-year projection...")
        projections, life_expectancy = model.run_projection()
        
        # Generate visualizations
        print("\nGenerating visualizations...")
        visualizer = MortalityVisualizer(model, save_dir=OUTPUT_DIR)
        vis_paths = visualizer.generate_all_visualizations()
        
        # Save projection results to CSV
        print("\nSaving projection data...")
        data_paths = save_projection_to_csv(projections, life_expectancy, OUTPUT_DIR)
        
        # Generate summary report
        print("\nGenerating summary report...")
        report_path = generate_summary_report(model, OUTPUT_DIR)
        
        # Display execution time
        end_time = datetime.now()
        duration = end_time - start_time
        print("\nExecution completed successfully!")
        print(f"Duration: {duration}")
        print("="*70)
        
    except Exception as e:
        print(f"\nError during execution: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main() 