"""
Visualization tools for long-term mortality projections
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import PercentFormatter, FuncFormatter
from matplotlib import cm
import seaborn as sns
import os
import warnings
warnings.filterwarnings('ignore')

# Configure plot aesthetics
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans'] 
# plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['figure.dpi'] = 100
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12
plt.rcParams['figure.titlesize'] = 20
plt.rcParams['font.family'] = 'DejaVu Sans'

sns.set_palette("colorblind")

# Custom colors
COLORS = {
    'M': '#1f77b4',  # Blue for males
    'F': '#e41a1c',  # Red for females
    'improvement': '#2ca02c',  # Green for improvements
}

class MortalityVisualizer:
    """
    Visualization tools for long-term mortality projections
    """
    
    def __init__(self, model, save_dir=None):
        """
        Initialize the visualizer
        
        Parameters:
        -----------
        model : LongTermMortalityModel
            The model containing projections
        save_dir : str
            Directory to save visualizations
        """
        self.model = model
        self.save_dir = save_dir or '.'
        
        # Ensure save directory exists
        os.makedirs(self.save_dir, exist_ok=True)
    
    def plot_life_expectancy_trend(self):
        """Plot the trend in life expectancy from 2025-2125"""
        plt.figure(figsize=(14, 8))
        
        years = self.model.projection_years
        
        # Plot life expectancy at birth for both genders
        for gender in ['M', 'F']:
            values = [self.model.life_expectancy[gender]['at_birth'][year] 
                     for year in years]
            
            gender_label = 'Female' if gender == 'F' else 'Male'
            plt.plot(years, values, color=COLORS[gender], linewidth=3, 
                     label=f"{gender_label} (e\u2080)")
            
            # Annotate starting and ending values - 调整位置避免超出边界
            plt.text(years[0], values[0]-0.15, f"{values[0]:.1f}", 
                    color=COLORS[gender], fontweight='bold')
            plt.text(years[-1]-10, values[-1]+0.05, f"{values[-1]:.1f}", 
                    color=COLORS[gender], fontweight='bold')
        
        # Calculate expected gain
        female_gain = self.model.life_expectancy['F']['at_birth'][years[-1]] - \
                    self.model.life_expectancy['F']['at_birth'][years[0]]
        male_gain = self.model.life_expectancy['M']['at_birth'][years[-1]] - \
                  self.model.life_expectancy['M']['at_birth'][years[0]]
                  
        # Add annotations - 调整位置避免与曲线重叠
        plt.text(years[0] + 15, self.model.life_expectancy['F']['at_birth'][years[0]] + female_gain/10,
                f"Female gain: +{female_gain:.1f} years", color=COLORS['F'], fontsize=14)
        plt.text(years[0] + 15, self.model.life_expectancy['M']['at_birth'][years[0]] + male_gain/4,
                f"Male gain: +{male_gain:.1f} years", color=COLORS['M'], fontsize=14)
        
        # Styling
        plt.title("Projected Life Expectancy at Birth (2025-2125)", fontsize=20, fontweight='bold')
        plt.xlabel("Year", fontsize=14)
        plt.ylabel("Life Expectancy (Years)", fontsize=14)
        plt.grid(True, alpha=0.3)
        plt.axvline(x=2025, linestyle='--', color='gray', alpha=0.5)
        
        # Highlight decade intervals
        for decade in range(2030, 2130, 10):
            plt.axvline(x=decade, linestyle=':', color='gray', alpha=0.2)
        
        # Show gender gap annotation - 调整位置避免重叠
        mid_y_2075 = (self.model.life_expectancy['F']['at_birth'][2075] + 
                     self.model.life_expectancy['M']['at_birth'][2075]) / 2
        
        plt.annotate(
            'Gender Gap',
            xy=(2075, mid_y_2075),
            xytext=(2075, mid_y_2075 - 2),  # 向下移动标注
            arrowprops=dict(arrowstyle='<->', color='gray', lw=1.5),
            color='gray',
            fontsize=12
        )
        
        plt.legend(loc='lower right')
        plt.tight_layout()
        
        # Save and show
        save_path = os.path.join(self.save_dir, 'life_expectancy_trend.png')
        plt.savefig(save_path)
        plt.close()
        
        return save_path
    
    def plot_mortality_curves(self, years=[2025, 2055, 2085, 2125]):
        """
        Plot mortality curves by age for selected years
        
        Parameters:
        -----------
        years : list
            List of years to include in the plot
        """
        fig, axs = plt.subplots(1, 2, figsize=(18, 8))
        years = sorted([y for y in years if y in self.model.projection_years])
        
        for i, gender in enumerate(['M', 'F']):
            ax = axs[i]
            gender_label = 'Male' if gender == 'M' else 'Female'
            
            for year in years:
                mortality = self.model.projections[gender]['mortality_rates'][year]
                ages = sorted(mortality.keys())
                rates = [mortality[age] for age in ages]
                
                # Use color gradients to show time progression
                color_idx = (years.index(year) / (len(years) - 1 if len(years) > 1 else 1))
                color = plt.cm.viridis(color_idx)
                
                ax.semilogy(ages, rates, label=f'{year}', linewidth=2.5, color=color)
            
            # Add Gompertz reference line for extreme ages (80+)
            if 2025 in years and 80 in mortality:
                log_rates = np.log(np.array([mortality[age] for age in range(80, 121)]))
                x = np.array(range(80, 121))
                coeffs = np.polyfit(x, log_rates, 1)
                gompertz_trend = np.exp(coeffs[1]) * np.exp(coeffs[0] * x)
                ax.semilogy(x, gompertz_trend, '--', color='gray', alpha=0.7, 
                          linewidth=1.5, label='Gompertz Trend')

            # Styling
            ax.set_title(f"{gender_label} Mortality Curves", fontsize=18, fontweight='bold')
            ax.set_xlabel("Age", fontsize=14)
            ax.set_ylabel("Mortality Rate (log scale)", fontsize=14)
            ax.set_ylim(1e-5, 1)
            ax.grid(True, which="both", linestyle='--', linewidth=0.5, alpha=0.7)
            ax.legend(loc='lower right')
            
            # Add age range markers
            for age in [0, 20, 40, 60, 80, 100, 120]:
                ax.axvline(x=age, linestyle=':', color='gray', alpha=0.3)
        
        plt.suptitle("Mortality Curves by Age (2025-2125)", fontsize=20, fontweight='bold')
        plt.tight_layout()
        
        # Save and show
        save_path = os.path.join(self.save_dir, 'mortality_curves.png')
        plt.savefig(save_path)
        plt.close()
        
        return save_path
    
    def plot_mortality_surface(self, gender='F'):
        """
        Create a 3D surface plot of mortality by age and year
        
        Parameters:
        -----------
        gender : str
            'M' or 'F'
        """
        from mpl_toolkits.mplot3d import Axes3D
        
        fig = plt.figure(figsize=(15, 10))
        ax = fig.add_subplot(111, projection='3d')
        
        # Get data
        years = self.model.projection_years
        ages = list(range(0, 121, 5))  # Sample every 5 years for cleaner visualization
        
        # Create mesh grid
        X, Y = np.meshgrid(ages, years)
        Z = np.zeros_like(X, dtype=float)
        
        # Fill mortality values
        for i, year in enumerate(years):
            mortality = self.model.projections[gender]['mortality_rates'][year]
            for j, age in enumerate(ages):
                Z[i, j] = mortality[age]
        
        # Create the surface plot with log scale for Z
        surf = ax.plot_surface(X, Y, np.log10(Z), cmap='viridis', 
                            linewidth=0, antialiased=True, alpha=0.8)
        
        # Add a color bar
        cbar = fig.colorbar(surf, ax=ax, shrink=0.6, aspect=10)
        cbar.set_label('Log10(Mortality Rate)', fontsize=14)
        
        gender_label = 'Female' if gender == 'F' else 'Male'
        ax.set_title(f"{gender_label} Mortality Surface (2025-2125)", fontsize=20, fontweight='bold')
        ax.set_xlabel('Age', fontsize=14)
        ax.set_ylabel('Year', fontsize=14)
        ax.set_zlabel('Log10(Mortality Rate)', fontsize=14)
        
        # Set viewpoint
        ax.view_init(elev=30, azim=240)
        
        # Save and show
        save_path = os.path.join(self.save_dir, f'mortality_surface_{gender}.png')
        plt.savefig(save_path)
        plt.close()
        
        return save_path
        
    def plot_improvement_rates(self):
        """Plot the trend in mortality improvement rates over time"""
        plt.figure(figsize=(14, 8))
        
        times = np.arange(0, 101, 5)  # Years from 2025
        years = np.array(self.model.projection_start_year) + times
        
        # Plot improvement rate decay for both genders
        for gender in ['M', 'F']:
            rates = [self.model.improvement_decay_function(t, gender) for t in times]
            gender_label = 'Female' if gender == 'F' else 'Male'
            plt.plot(years, rates, color=COLORS[gender], linewidth=3, label=gender_label)
        
        # Add reference lines for key years
        plt.axvline(x=2050, linestyle='--', color='gray', alpha=0.5, 
                   label='Reference Years')
        plt.axvline(x=2075, linestyle='--', color='gray', alpha=0.5)
        plt.axvline(x=2100, linestyle='--', color='gray', alpha=0.5)
        
        # Formatting
        plt.title("Annual Mortality Improvement Rates (2025-2125)", 
                 fontsize=20, fontweight='bold')
        plt.xlabel("Year", fontsize=14)
        plt.ylabel("Annual Improvement Rate", fontsize=14)
        plt.grid(True, alpha=0.3)
        plt.gca().yaxis.set_major_formatter(PercentFormatter(1.0))
        
        # 调整说明文字位置，向下移动避开横轴刻度
        # 使用figure坐标系而不是数据坐标系定位文本
        plt.figtext(0.25, 0.15, 
                 "Gradually slowing improvement rates\nreflect diminishing returns in\nmortality reduction over time",
                 color='gray', fontsize=12, alpha=0.8)
        
        plt.legend(loc='upper right')
        plt.tight_layout()
        
        # Save and show
        save_path = os.path.join(self.save_dir, 'improvement_rates.png')
        plt.savefig(save_path)
        plt.close()
        
        return save_path
    
    def plot_age_specific_improvements(self, year=2075):
        """
        Plot age-specific improvement rates for a specific year
        
        Parameters:
        -----------
        year : int
            Projection year to analyze
        """
        if year not in self.model.projection_years:
            closest_year = min(self.model.projection_years, key=lambda y: abs(y - year))
            year = closest_year
            print(f"Year {year} not in projection years. Using closest year: {closest_year}")
        
        plt.figure(figsize=(14, 8))
        
        for gender in ['M', 'F']:
            year_offset = year - self.model.projection_start_year
            ages = range(0, 121)
            
            improvements = [self.model.age_specific_improvement_pattern(age, gender, year_offset) 
                           for age in ages]
            
            gender_label = 'Female' if gender == 'F' else 'Male'
            plt.plot(ages, improvements, color=COLORS[gender], linewidth=3, label=gender_label)
        
        # Add age range markers
        plt.axvspan(0, 10, alpha=0.1, color='green', label='Childhood')
        plt.axvspan(10, 40, alpha=0.1, color='blue', label='Young Adult')
        plt.axvspan(40, 65, alpha=0.1, color='orange', label='Middle Age')
        plt.axvspan(65, 85, alpha=0.1, color='purple', label='Senior')
        plt.axvspan(85, 120, alpha=0.1, color='red', label='Elderly')
        
        plt.title(f"Age-Specific Mortality Improvement Rates in {year}", 
                 fontsize=20, fontweight='bold')
        plt.xlabel("Age", fontsize=14)
        plt.ylabel("Annual Improvement Rate", fontsize=14)
        plt.grid(True, alpha=0.3)
        plt.gca().yaxis.set_major_formatter(PercentFormatter(1.0))
        
        # 移除所有说明性文本注释，让数据自己说话
        
        plt.legend(loc='upper right')
        plt.tight_layout()
        
        # Save and show
        save_path = os.path.join(self.save_dir, f'age_improvements_{year}.png')
        plt.savefig(save_path)
        plt.close()
        
        return save_path
    
    def plot_advanced_age_mortality(self):
        """Plot mortality at advanced ages to demonstrate Gompertz pattern"""
        plt.figure(figsize=(14, 8))
        
        # 修改范围：从0岁到80岁，避免使用数据质量较差的高龄数据
        age_range = range(0, 81)
        years = [2025, 2075, 2125]
        
        for gender in ['M', 'F']:
            # Plot for each selected year
            for year in years:
                mortality = self.model.projections[gender]['mortality_rates'][year]
                rates = [mortality[age] for age in age_range]
                
                # Use different line styles for different years
                style = '-' if year == 2025 else '--' if year == 2075 else '-.'
                lw = 3 if year == 2025 else 2.5 if year == 2075 else 2
                gender_label = 'Female' if gender == 'F' else 'Male'
                
                plt.semilogy(age_range, rates, 
                           linestyle=style, linewidth=lw,
                           color=COLORS[gender], 
                           label=f"{gender_label} {year}")
        
        plt.title("Age-Specific Mortality Rates (2025-2125)", 
                 fontsize=20, fontweight='bold')
        plt.xlabel("Age", fontsize=14)
        plt.ylabel("Mortality Rate (log scale)", fontsize=14)
        plt.grid(True, which="both", linestyle='--', linewidth=0.5, alpha=0.7)
                
        # plt.gca().yaxis.set_major_formatter(PercentFormatter(1.0))
        
        # Add key age markers
        for age in [20, 40, 60, 80]:
            plt.axvline(x=age, color='gray', linestyle=':', alpha=0.4)
        
        # 移除所有说明性文字，让数据自己说话
        
        plt.legend(loc='lower right')
        plt.tight_layout()
        
        # Save and show
        save_path = os.path.join(self.save_dir, 'advanced_age_mortality.png')
        plt.savefig(save_path)
        plt.close()
        
        return save_path
    
    def generate_all_visualizations(self):
        """Generate all visualizations"""
        print("Generating visualizations...")
        
        # Main visualizations
        paths = [
            self.plot_life_expectancy_trend(),
            self.plot_mortality_curves(),
            self.plot_improvement_rates(),
            self.plot_age_specific_improvements(),
            self.plot_advanced_age_mortality()
        ]
        
        # 3D surface plots (more computationally intensive)
        for gender in ['M', 'F']:
            try:
                paths.append(self.plot_mortality_surface(gender))
            except Exception as e:
                print(f"Could not generate 3D surface plot for {gender}: {e}")
        
        print(f"Generated {len(paths)} visualizations:")
        for path in paths:
            print(f"  - {path}")
        
        return paths 